# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 10:37:11 2024

@author: elx22yz
"""

''' 07/03/2024
    Version 0.0.1
    This is the function to generate Sqrt into the record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''

from Add_Into_Structure_Array_Else import Add_Into_Structure_Array_Else
import itertools
from Template import Max_number_operands     
from Template import Max_number_results

def Sqrt_Else_V(b, a):
      
    results = list(itertools.repeat('0', Max_number_results))
    results[0] = b
    inputs = list(itertools.repeat('0', Max_number_operands))
    inputs[0] = a  
    operator_num = 7
    number_of_operands = 1
    number_of_results = 1
    
    Add_Into_Structure_Array_Else(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)