# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 16:48:29 2024

@author: elx22yz
"""

"""
14/06/2024

This function is to update the resource info of the user designed func for the 
future resource estimation

"""

import lib_resource_newfun
import lib_para
import lib_resource_fundamental
import lib_resource_newfun
import IfElse_Arrays



def new_fun_res_update(a):
    LUT_array_T = lib_resource_newfun.LUT_array
    FF_array_T = lib_resource_newfun.FF_array
    DSP_array_T = lib_resource_newfun.DSP_array
    BRAM_array_T = lib_resource_newfun.BRAM_array
    
    binary_tree_main = lib_para.Eq_record
    counter_all = lib_para.Address_counter
    
    LUT = 0
    FF = 0
    DSP = 0
    BRAM = 0
    
    
    
    for i in range(0, counter_all + 1):
        
        operator = binary_tree_main[i]['operator'] 
        
        if(operator<1000 and operator>0):
            LUT = LUT + lib_resource_fundamental.LUT_array[operator]
            FF = FF + lib_resource_fundamental.FF_array[operator]
            DSP = DSP + lib_resource_fundamental.DSP_array[operator]
            BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
        elif(operator>1000):
            LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
            FF = FF + lib_resource_newfun.FF_array[operator-1000]
            DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
            BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]
    

    # If Else Array
    for i in range(0, lib_para.If_counter):
        for j in range (0, IfElse_Arrays.if_delay[i]):
            operator = IfElse_Arrays.if_array[i][j]['operator'] 
            
            if(operator<1000 and operator>0):
                LUT = LUT + lib_resource_fundamental.LUT_array[operator]
                FF = FF + lib_resource_fundamental.FF_array[operator]
                DSP = DSP + lib_resource_fundamental.DSP_array[operator]
                BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
            elif(operator>1000):
                LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
                FF = FF + lib_resource_newfun.FF_array[operator-1000]
                DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
                BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]
            
            
    # Else Else Array
    for i in range(0, lib_para.If_counter):      
        for j in range (0, IfElse_Arrays.else_delay[i]):
              operator = IfElse_Arrays.else_array[i][j]['operator'] 
              
              if(operator<1000 and operator>0):
                  LUT = LUT + lib_resource_fundamental.LUT_array[operator]
                  FF = FF + lib_resource_fundamental.FF_array[operator]
                  DSP = DSP + lib_resource_fundamental.DSP_array[operator]
                  BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
              elif(operator>1000):
                  LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
                  FF = FF + lib_resource_newfun.FF_array[operator-1000]
                  DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
                  BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]      
            
    LUT_array_T.append(LUT)
    FF_array_T.append(FF)
    DSP_array_T.append(DSP)
    BRAM_array_T.append(BRAM)
    
    
    
    f = open("lib_resource_newfun.py", "w")
    
    f.write("LUT_array = [")
    
    
    for i in range(0, len(LUT_array_T)):
        if(i!=len(LUT_array_T)-1):
            f.write(str(LUT_array_T[i]) + ", " )
        else:
            f.write(str(LUT_array_T[i]) + "]\n" )
      
    f.write("FF_array = [")
    for i in range(0, len(FF_array_T)):
        if(i!=len(FF_array_T)-1):
            f.write(str(FF_array_T[i]) + ", " )
        else:
            f.write(str(FF_array_T[i]) + "]\n" )
        
    f.write("DSP_array = [")
    for i in range(0, len(DSP_array_T)):
        if(i!=len(DSP_array_T)-1):
            f.write(str(DSP_array_T[i]) + ", " )
        else:
            f.write(str(DSP_array_T[i]) + "]\n" )
            
            
            
    f.write("BRAM_array = [")
    for i in range(0, len(BRAM_array_T)):
        if(i!=len(BRAM_array_T)-1):
            f.write(str(BRAM_array_T[i]) + ", " )
        else:
            f.write(str(BRAM_array_T[i]) + "]\n" )
    
    
    f.close()
    
    
    lib_resource_newfun
    
    