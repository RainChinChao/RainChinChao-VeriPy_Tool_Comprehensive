"""
Created on Wed Feb 28 09:39:56 2024

@author: elx22yz
"""

''' 28/02/2024
    Version 0.0.1    
    This function is a template for every existing fundamental functions of +, 
    -, *, /, sin/cos/tan, power, sqrt, log, value(賦值).
    By using this temmplate, a structure/class containing operant, operator,
    result, previous address(could be 2), number of operants, and number of 
    results(this one is currently optional)
'''

import numpy as np
counter_no_of_eq = 0;

 
dt= np.dtype([
              ('operand1', (np.str_, 10)), 
              ('operand2', (np.str_, 10)),
              # Length of operands' names could not exceed 10 characters
              ('number_of_operands', (np.int8)),
              # This is for more than one operands
              ('operator', np.int8),
              # 1 +, 2 -, 3 *, 4 /, 5 power, 6 log, 7 sqrt, 8 sin/cos/tan, 
              # 9 value(賦值) 
              ('result', (np.str_, 10)),
              # Length of results' names could not exceed 10 characters
              ('previous_address', (np.int32)),
              #This is for 
              ('previous_address1', (np.int8))
              ]) 


a = np.array([('a', 'b', 2, 1, 'c', 2, 2), ('a', 'b', 2, 1, 'c', 2, 1)],  
       dtype=dt) 


print(a[0]['operand1'])