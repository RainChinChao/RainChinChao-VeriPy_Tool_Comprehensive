# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 15:23:50 2024

@author: elx22yz
"""
''' 25/04/2024
    Version 0.0.1
    This is the function to generate same name array. For example, if developer
    need a A[100], we will connnect this reg A[100] to 100 wires.
    reg [100]A[31:0];
    wire 1
    
'''
import lib_para


def array_define(array_name, array_size):
    
    
    lib_para.array_names.append(array_name)
    lib_para.array_sizes.append(array_size)
    
    
    