# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 09:46:12 2024

@author: elx22yz
"""

''' 08/04/2024
    Version 0.0.1
    This is the function to generate the Verilog top file according to the 
    Main Binary Tree and If/Else Binary Tree.
    
'''


import numpy as np
from Template import dt
import IfElse_Arrays
import lib_para
from Verilog_IF_Else_Gen import if_module_gen
from Verilog_IF_Else_Gen import else_module_gen
import Verilog_IF_Else_Gen
import Verilog_IF_Else_Inout_Gen
from array_print_top import array_print_top
from input_output_print_top import input_output_print_top
from array_content_print_top import array_content_print_top
from result_address_finder import result_address_finder
import lib_in_out_names 
from recall_function import recall_function



file_name = 0



# define result names
result_names_if = []
result_name_no_if = []
result_names_counter_if = 0
 
result_names_else = []
result_name_no_else = []
result_names_counter_else = 0


def result_name_adder(na, file_name):
                 
    f = open(file_name, "a")    
    f.write("\twire [31:0]" + na + ";\n")   
    f.close()
        
   
    return na



def input_name_decider(na, file_name):
    
    # When there is nothing in the array
    if(lib_in_out_names.input_names_counter == 0):
        lib_in_out_names.input_names.append(str(na))
        lib_in_out_names.input_name_no.append(1)
        lib_in_out_names.input_names_counter = 1
        new_result_name = na
        
        f = open(file_name, "a")
        f.write("\twire [31:0]" + new_result_name + "_gen_new;\n")
        f.close()
    
    # When there are already some records inside the array
    else:
        
        # Flag to boolean if there is the same name recorded before
        flag = 0
        for j in range (0, lib_in_out_names.input_names_counter):
            if(lib_in_out_names.input_names[j] == str(na)):
                flag = 1
                temp_j=j
        
        # When there is the same name record before
        if(flag == 1):

            lib_in_out_names.input_name_no[temp_j] = lib_in_out_names.input_name_no[temp_j] + 1
            new_result_name = str(na) + "_gen_new_" + str(lib_in_out_names.input_name_no[temp_j])

            f = open(file_name, "a")
            f.write("\twire [31:0]" + new_result_name + ";\n")
            f.close()
            
        # When it is the first time to record this name   
        else:
            lib_in_out_names.input_names.append(str(na))
            lib_in_out_names.input_name_no.append(1)
            lib_in_out_names.input_names_counter = lib_in_out_names.input_names_counter + 1
            new_result_name = na
            
            f = open(file_name, "a")            
            f.write("\twire [31:0]" + new_result_name + "_gen_new;\n")
            f.close()

    return new_result_name


   
  

























# a is the name of your design
def PyToVer(a):
    
    file_name = a + '.v'   
    
    
    
    # Print input/output names
    
    # Code the beginning of the Verilog File
    # module name, input/output signals
    f = open(file_name, "w")
    # module name, input signals
    f.write("module " + str(a) + "(input [31:0]I, input [31:0]Q, ")
    
    for i in range(0, len(lib_para.output_names)):
        f.write("output [31:0]" + lib_para.output_names[i] + ", ")
    
    # control signals
    f.write("input start, input reset, output valid, output busy);\n")
    
    f.close()
    
    
    
    # Generate array first
    array_print_top(file_name)
    array_content_print_top(file_name)
    
    
    
    f = open(file_name, "a")
    f.write("\n")
    f.close()
    
    
    
    
    
    
    
    # store every equation's output inside the array (from main binary tree)
    counter_all = lib_para.Address_counter
    binary_tree_main = lib_para.Eq_record
    for i in range (0, counter_all + 1):
        results = binary_tree_main[i]['result_name_array']
        no_results = binary_tree_main[i]['number_of_results']
        
        for j in range (0, no_results):
        
            lib_in_out_names.input_names.append(str(results[j]))
            lib_in_out_names.input_name_no.append(1)
            lib_in_out_names.input_names_counter = lib_in_out_names.input_names_counter + 1
    
    
    
    # store every equation's output inside the array (from if/else binary tree)
    # since if/else share the same output, just need to pick one of those to do
    
    # Do the if/else tree one by one
    for i in range (0, lib_para.If_counter):
        if_binary_tree = IfElse_Arrays.if_array[i]
        
        for j in range (0, IfElse_Arrays.if_delay[i]):
            if_result = if_binary_tree[j]['result_name_array']
            if_no_results = if_binary_tree[j]['number_of_results']
            
            for k in range (0, if_no_results):
            
                lib_in_out_names.result_names_if.append(str(if_result[k]))
                lib_in_out_names.result_name_no_if.append(1)
                lib_in_out_names.result_names_counter_if = lib_in_out_names.input_names_counter + 1
    
    
    
    
    

    # Find the address of the result set by users
    # Find branches in different result
    for i in range (0, len(lib_para.output_names)):
        previous_address = result_address_finder(lib_para.output_names[i])
    
        # When there is only 1 previous address of the result:
        if(len(previous_address) == 1):
            
            recall_function(previous_address, 1, file_name)
            
            
        # If there are more than 1 previous address of the result
        # This means the last result is calculated in If/Else statement 
        else:
            
            for j in range (0, len(previous_address)):
                recall_function(previous_address[j], 1, file_name)
 
    
 
    
 
    
 
    
 
    
 
    
 
    
 
    
 
 
    binary_tree_main = lib_para.Eq_record
    counter_all = lib_para.Address_counter
   
    no_if = lib_para.If_counter
    else_count = lib_para.Else_counter
    storage_delay_if = IfElse_Arrays.if_delay
    storage_delay_else = IfElse_Arrays.else_delay
    storage_binary_tree_if = IfElse_Arrays.if_array
    storage_binary_tree_else = IfElse_Arrays.else_array
    if_addresses = IfElse_Arrays.start_address_if
    
    
    
    # Initialize the count of different equations
    if_count = 0
    add_count = 0
    substract_count = 0
    mul_count = 0
    div_count = 0
    power_count = 0
    log_count = 0
    sqrt_count = 0
    sincostan_count = 0
    value_count = 0
    
    
    
    
    
    previous_valid = "start"
    
    
    
    # define result names
    global result_names
    global result_name_no
    global result_names_counter
    
    
    
    
    for i in range(0, counter_all + 1):
        operands = binary_tree_main[i]['operand_name_array']
        no_operands = binary_tree_main[i]['number_of_operands']        
        operator = binary_tree_main[i]['operator'] 
        results = binary_tree_main[i]['result_name_array']
        no_results = binary_tree_main[i]['number_of_results']
        previous_addresses = binary_tree_main[i]['previous_address']
        no_previous_adresses = binary_tree_main[i]['no_of_previous_address']
        delay_cycles = binary_tree_main[i]['delay cycles']
        
        
        
        # To classify If/Else
        if(binary_tree_main[i]['operator'] == 10):
            # Need to search in If/Else Binary Tree
            #a=0
            
            name_comp_if = "if_HDL_" + str(if_count)
            name_comp_else = "else_HDL_" + str(if_count)
            
            # Initialize the array in Verilog_IF_Else_Gen
            Verilog_IF_Else_Gen.result_names_if = []
            Verilog_IF_Else_Gen.result_name_no_if = []
            Verilog_IF_Else_Gen.result_names_counter_if = 0
             
            Verilog_IF_Else_Gen.result_names_else = []
            Verilog_IF_Else_Gen.result_name_no_else = []
            Verilog_IF_Else_Gen.result_names_counter_else = 0
            Verilog_IF_Else_Gen.if_input_names = []
            Verilog_IF_Else_Gen.else_input_names = []
            
            
            
            
            Verilog_IF_Else_Inout_Gen.result_names_if = []
            Verilog_IF_Else_Inout_Gen.result_name_no_if = []
            Verilog_IF_Else_Inout_Gen.result_names_counter_if = 0
             
            Verilog_IF_Else_Inout_Gen.result_names_else = []
            Verilog_IF_Else_Inout_Gen.result_name_no_else = []
            Verilog_IF_Else_Inout_Gen.result_names_counter_else = 0
            Verilog_IF_Else_Inout_Gen.if_input_names = []
            Verilog_IF_Else_Inout_Gen.else_input_names = []
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            # Initialize the array
            if_input_name = []
            if_output_name = []
            
            
             
            
            file_if = "if_self_gen_" + str(if_count) + ".v"
            
            
            
            
            Verilog_IF_Else_Inout_Gen.if_module_inout_gen(if_count, file_if)
            
            
            
            # Write if input/output info in .v file
            fun_name = "if_self_gen_" + str(if_count)
            #print(fun_name)
            f = open(file_if, "w")
            f.write("module " + fun_name + "( input clk, input start, input reset, output valid, output busy, "       
                         )
            
            f.close()
            
            
            # Write the input info
            for j in range(0, len(Verilog_IF_Else_Inout_Gen.if_input_names)):
                f = open(file_if, "a")
                
                f.write("input [31:0]"+ str(Verilog_IF_Else_Inout_Gen.if_input_names[j])        
                             )
                
                if(j<=len(Verilog_IF_Else_Inout_Gen.if_input_names)-2):
                    f.write(", " )
                f.close()
            
                
            # Write the output info
            if(len(Verilog_IF_Else_Inout_Gen.result_names_if) != 0):
                f = open(file_if, "a")
                f.write(", " )
                f.close()
                for j in range(0, len(Verilog_IF_Else_Inout_Gen.result_names_if)):
                    #print(Verilog_IF_Else_Inout_Gen.result_names_if[j])
                    
                    if(Verilog_IF_Else_Inout_Gen.result_name_no_if[j]==1):
                        f = open(file_if, "a")
                        
                        f.write("output [31:0]"+ str(Verilog_IF_Else_Inout_Gen.result_names_if[j])        
                                      )
                    else:
                        f = open(file_if, "a")
                        f.write("output [31:0]" +
                                str(Verilog_IF_Else_Inout_Gen.result_names_if[j]) 
                                + "_gen_new_"+str(Verilog_IF_Else_Inout_Gen.result_name_no_if[j])
                                )
                    
                    if(j<=len(Verilog_IF_Else_Inout_Gen.result_names_if)-2):
                        f.write(", " )
                    f.close()   
                
                
                
                
            f = open(file_if, "a")    
            f.write("); \n" )
                
            f.close()
            
            
            
            
            
            
            if_module_gen(if_count, file_if)
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            if_input_name = []
            if_output_name = []
            
            if_input_name_for_combine = []
            if_output_name_for_combine = []
            
            #if_output_name_for_combine_without_sign = []
            
            #print(str(Verilog_IF_Else_Inout_Gen.if_output_names[0]))
            # Proceed with the input names
            for j in range(0, len(Verilog_IF_Else_Inout_Gen.if_input_names)):
                if_input_name.append(input_name_decider(Verilog_IF_Else_Gen.if_input_names[j]))
                new_input_name_if = input_name_decider(Verilog_IF_Else_Gen.if_input_names[j])
                
   
            # Proceed with the output names
            if(len(Verilog_IF_Else_Inout_Gen.result_names_if) != 0):
                for j in range(0, len(Verilog_IF_Else_Inout_Gen.result_names_if)):
                    #print(Verilog_IF_Else_Inout_Gen.result_names_if[j])
                    #temp_output_name = result_name_adder(Verilog_IF_Else_Inout_Gen.result_names_if[j])
                    #if_output_name.append(temp_output_name)
                    #new_output_name_if = temp_output_name
                    if(Verilog_IF_Else_Inout_Gen.result_name_no_if[j] == 1):
                        temp_name_if_output = Verilog_IF_Else_Inout_Gen.result_names_if[j]
                    else:
                        temp_name_if_output = Verilog_IF_Else_Inout_Gen.result_names_if[j] + "_gen_new_" + str(Verilog_IF_Else_Inout_Gen.result_name_no_if[j])
                        #temp_name_if_output_without_sign = 
                    if_output_name_for_combine.append(temp_name_if_output)
            
            #Verilog_IF_Else_Gen.result_name_no_if
            
            
            # Print in the top file
            start_line_name_if = "start_" + name_comp_if
            valid_line_name_if = "valid_" + name_comp_if 
            busy_line_name_if = "busy_" + name_comp_if
            
            
            
            
            
            
            
            
            
            
            
            # Print condition function in the combined file
            
            combined_file_name = "if_else_self_gen" + str(if_count) +".v"
            
            # Write in the top module
            f = open(combined_file_name, "w")
            
            # Comments
            f.write("\n\n\n\t//Proceed with if_section calculation.\n")
            
            
            f.write("\twire "+ start_line_name_if +";\n" + 
                    "\twire "+ valid_line_name_if +";\n" +
                    "\twire "+ busy_line_name_if +";\n"        
                         )
            
            f.write("\tif_self_gen_" + str(if_count) +" "+ name_comp_if +"(" +  
                    " clk, " + start_line_name_if + ", reset, " +
                    valid_line_name_if + ", " + busy_line_name_if + ", "
                    
                         )
            
            
            
            
            
            for j in range(0, len(if_input_name)):
                # Write the input name into the top file
                f = open(combined_file_name, "a")
                f.write(if_input_name[j])
                f.close()
                #print(if_input_name[j])
                # Write the comma after input names
                if(j<=len(if_input_name)-2):
                    f = open(combined_file_name, "a")
                    f.write(", ")
                    f.close()
                
            # Proceed with the output names
            if(len(if_output_name_for_combine) != 0):
                f = open(combined_file_name, "a")
                f.write(", ")
                f.close()
                for j in range(0, len(if_output_name_for_combine)):
                    #print(new_output_name_if)
                    # Write the input name into the top file
                    f = open(combined_file_name, "a")
                    f.write(if_output_name_for_combine[j]+ "_if")
                    f.close()
                    
                    # Write the comma after input names
                    if(j<=len(if_output_name_for_combine)-2):
                        f = open(combined_file_name, "a")
                        f.write(", ")
                        f.close()
            
            
            
            
            
            
            
            
            f.close()
            
            
            f = open(combined_file_name, "a")
            f.write(");\n")
            
            
            f.write("\tassign "+ start_line_name_if + " = " + " start;\n\n\n"        
                         )
            
            for j in range(0, len(if_output_name_for_combine)):
                 f.write("\twire [31:0]"+ if_output_name_for_combine[j] + "_if;\n\n\n"        
                              )   
            
            
            
            f.close()
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
           
            
            
            
            
            
            
            # Else gen
            
            
            else_input_name = []
            else_output_name = []
            
            
 
            file_else = "else_self_gen_" + str(if_count) + ".v"
            
            Verilog_IF_Else_Inout_Gen.else_module_inout_gen(if_count, file_else)
            
            # Write if input/output info in .v file
            fun_name = "else_self_gen_" + str(if_count)
            f = open(file_else, "w")
            f.write("module " + fun_name +  "( input clk, input start, input reset, output valid, output busy,"        
                         )
            
            f.close()
            
            
            
            # Write the input info
            for j in range(0, len(Verilog_IF_Else_Inout_Gen.else_input_names)):
                f = open(file_else, "a")
                
                f.write("input [31:0]"+ str(Verilog_IF_Else_Inout_Gen.else_input_names[j])        
                             )
                #print(len(Verilog_IF_Else_Inout_Gen.else_input_names[j]))
                if(j<=len(Verilog_IF_Else_Inout_Gen.else_input_names)-2):
                    f.write(", " )
                f.close()
            
            
            
            # Write the output info
            if(len(Verilog_IF_Else_Inout_Gen.result_names_else) != 0):
                if(len(Verilog_IF_Else_Inout_Gen.else_input_names)>0):
                    f = open(file_else, "a")
                    f.write(", " )
                    f.close()
                for j in range(0, len(Verilog_IF_Else_Inout_Gen.result_names_else)):
                    #print(Verilog_IF_Else_Inout_Gen.result_names_if[j])
                    f = open(file_else, "a")
                    
                    
                    if(Verilog_IF_Else_Inout_Gen.result_name_no_else[j]==1):
                    
                        f.write("output [31:0]"+ str(Verilog_IF_Else_Inout_Gen.result_names_else[j])        
                                      )
                    
                    else:
                        f.write("output [31:0]"+ str(Verilog_IF_Else_Inout_Gen.result_names_else[j]) + "_gen_new_"        
                                +  str(Verilog_IF_Else_Inout_Gen.result_name_no_else[j])    
                                )
                    
                    
                    
                    if(j<=len(Verilog_IF_Else_Inout_Gen.result_names_else)-2):
                        f.write(", " )
                    f.close()   
                
                
            
            f = open(file_else, "a")    
            f.write("); \n" )
                
            f.close()
            
            
            
            
            
            
            else_module_gen(if_count, file_else)
            
            
            
            start_line_name_else = "start_" + name_comp_else
            valid_line_name_else = "valid_" + name_comp_else 
            busy_line_name_else = "busy_" + name_comp_else
            
            
            
            
            
            
  
            
            
            
            
            
            
            
            
            
            
            
            
            
            # Generate the else_input_name
            
            else_input_name = []
            else_output_name = []


            else_input_name_for_combine = []
            else_output_name_for_combine = []
            


            for j in range(0, len(Verilog_IF_Else_Inout_Gen.else_input_names)):
                else_input_name.append(input_name_decider(Verilog_IF_Else_Inout_Gen.else_input_names[j]))
                #new_input_name_else = input_name_decider(Verilog_IF_Else_Gen.else_input_names[j])

            
            
            # Proceed with the output names
            if(len(Verilog_IF_Else_Inout_Gen.result_names_else) != 0):

                for j in range(0, len(Verilog_IF_Else_Inout_Gen.result_names_else)):
                    #temp_output_name = result_name_adder(Verilog_IF_Else_Inout_Gen.result_names_else[j])
                    #else_output_name.append(temp_output_name)
                    #new_output_name_else = temp_output_name
                    if(Verilog_IF_Else_Inout_Gen.result_name_no_else[j] == 1):
                        temp_name_else_output = Verilog_IF_Else_Inout_Gen.result_names_else[j]
                    else:
                        temp_name_else_output = Verilog_IF_Else_Inout_Gen.result_names_else[j] + "_gen_new_" + str(Verilog_IF_Else_Inout_Gen.result_name_no_else[j])
                    else_output_name_for_combine.append(temp_name_else_output)
        

            
           
           







        










            
            
            
            
            
            
            # Print condition function in the combined file
            
            combined_file_name = "if_else_self_gen" + str(if_count) +".v"
            
            f = open(combined_file_name, "a")
            # Comments
            f.write("\t//Proceed with else_section calculation.\n")
            
            f.write("\twire "+ start_line_name_else +";\n" + 
                    "\twire "+ valid_line_name_else +";\n" +
                    "\twire "+ busy_line_name_else +";\n"        
                         )
            
            f.write("\telse_self_gen_"+ str(if_count) +" "+name_comp_else +"(" +  
                    " clk, " + start_line_name_else + ", reset, " +
                    valid_line_name_else + "," + busy_line_name_else + ", "
                    
                         )
            
            
            
            for j in range(0, len(else_input_name)):
                # Write the input name into the top file
                f = open(combined_file_name, "a")
                f.write(else_input_name[j])
                f.close()
                
                # Write the comma after input names
                if(j<=len(else_input_name)-2):
                    f = open(combined_file_name, "a")
                    f.write(", ")
                    f.close()
            
            
            # Proceed with the output names
            if(len(else_output_name_for_combine) != 0):
                if(len(else_input_name)>0):
                    f = open(combined_file_name, "a")
                    f.write(", ")
                    f.close()
                for j in range(0, len(else_output_name_for_combine)):
                    # Write the input name into the top file
                    #print(else_output_name[j])
                    f = open(combined_file_name, "a")
                    f.write(else_output_name_for_combine[j] + "_else")
                    f.close()
                    
                    # Write the comma after input names
                    if(j<=len(else_output_name_for_combine)-2):
                        f = open(combined_file_name, "a")
                        f.write(", ")
                        f.close()
            f = open(combined_file_name, "a")
            f.write(");\n")
            
            
            
            for j in range(0, len(if_output_name_for_combine)):
                 f.write("\twire [31:0]"+ else_output_name_for_combine[j] + "_else;\n\n\n"        
                              )    
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            f.write("\tassign "+ start_line_name_else + " =  start ;\n\n\n"        
                         )
            
            f.close()       
            
            
            
            
            
            
            
            
            
            # Print condition function in the combined file
            
            combined_file_name = "if_else_self_gen" + str(if_count) +".v"
            
            f = open(combined_file_name, "a")   
            # Comments
            f.write("\t//Proceed with if_condition.\n")
            
            
            f.write("\twire if_condition_"+str(if_count)+";\n ")
            f.write("\tif_V"+ str(if_count)
                    +" if_con"+str(if_count)+"( clk, start_if_con_"+str(if_count)+" ,reset,"+ 
                    " valid_if_con_"+str(if_count)+", busy_if_con"+str(if_count)+"," )
                
            f.close()
            
            
            for j in range (0, no_operands):
                f = open(combined_file_name, "a")    
                if(operands[j].isnumeric()):
                    sde=0
                    if(j<no_operands-1):
                        f = open(combined_file_name, "a")    
                        f.write(" ")
                            
                        f.close()
                    else:
                        f = open(combined_file_name, "a")    
                        f.write(" if_condition_"+str(if_count)+");\n\n\n ")
                            
                        f.close()
                else:
                    f.write(operands[j])
                    
                    f.close()
                    if(j<no_operands-1):
                        f = open(combined_file_name, "a")    
                        f.write(", ")
                            
                        f.close()
                    else:
                        f = open(combined_file_name, "a")    
                        f.write(", if_condition_"+str(if_count)+");\n\n\n ")
                            
                        f.close()

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            f = open(combined_file_name, "a")   
            # Comments
            f.write("\tassign start_if_con_" + str(if_count) +" = start;\n\n\n")
            f.close()
            
            
            
            output_if_else_self_gen = []
            
            f = open(combined_file_name, "a")   
            # Comments
            
            for k in range (0, len(lib_in_out_names.result_names_if)):
                for l in range (0, len(lib_in_out_names.result_names_else)): 
                    if(lib_in_out_names.result_names_if[k] == lib_in_out_names.result_names_else[l]):
                        if(lib_in_out_names.result_name_no_if[k] == 1):
                            out_name_if = lib_in_out_names.result_names_if[k] + "_if"
                        else: 
                            out_name_if = lib_in_out_names.result_names_if[k] + "_gen_new_" + str(lib_in_out_names.result_name_no_if[k]) + "_if"
                        
                        if(lib_in_out_names.result_name_no_else[k] == 1):
                            out_name_else = lib_in_out_names.result_names_else[l] + "_else"
                        else: 
                            out_name_else = lib_in_out_names.result_names_else[l] + "_gen_new_" + str(lib_in_out_names.result_name_no_else[l]) + "_else"
                        
                        output_combine = lib_in_out_names.result_names_if[k] + "_combine"
                        
                        f.write("\tassign "+ output_combine + " = if_condition_"+str(if_count)+" ? "+out_name_if +" : "+ out_name_else+";\n\n\n")
                        
                        output_if_else_self_gen.append(output_combine)
            
            
            
            f.close()
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            if_names_proceed = Verilog_IF_Else_Inout_Gen.result_names_if 
            if_names_counter = Verilog_IF_Else_Inout_Gen.result_name_no_if 
            
             
            else_names_proceed = Verilog_IF_Else_Inout_Gen.result_names_else
            else_names_counter = Verilog_IF_Else_Inout_Gen.result_name_no_else
            
            
            final_if_names = []
            
            for j in range (0, len(if_names_proceed)):
                if(if_names_counter[j] == 1):
                    final_if_names.append(if_names_proceed[j]+"_if")
                else:
                    final_if_names.append(if_names_proceed[j] + "_gen_new_" + str(if_names_counter[j])+"_if")
                #print(if_names_proceed[j] + "_gen_new_" + str(if_names_counter[j]))
            
            
            for j in range (0, len(else_names_proceed)):
                if(else_names_counter[j] == 1):
                    final_if_names.append(else_names_proceed[j]+"_else")
                else:
                    final_if_names.append(else_names_proceed[j] + "_gen_new_" + str(else_names_counter[j])+"_else")
            
                #print(else_names_proceed[j] + "_gen_new_" + str(else_names_counter[j]))
            
            for j in range (0, len(final_if_names)):
                #print(final_if_names[j])
                a=0
            
            
            
            
            # In one function:
                
            
            # set1 = set(if_input_name)
            # set2 = set(else_input_name)
            # combined_input_names = list(set1.union(set2))
            #print(len(combined_input_names))
            
            
            set5 = set(Verilog_IF_Else_Gen.if_input_names)
            set6 = set(Verilog_IF_Else_Gen.else_input_names)
            combined_input_names_pure = list(set5.union(set6))
            combined_input_names = []
            for j in range(0, len(combined_input_names_pure)):
                combined_input_names.append(input_name_decider(combined_input_names_pure[j]))
            
            if_output_name_new=[]
            else_output_name_new=[]
            
           
            
            
            
            
            
            if(operands[0].isnumeric()):
                a_part = ""
            else:
                a_part = "input [31:0]" + operands[0] + ", " 
            
            if(operands[1].isnumeric()):
                b_part = ""
            else:
                b_part = "input [31:0]" + operands[1] + ", " 
            
            
            define_a_b = a_part + b_part
            
            in_out_state = "module if_else_self_gen_" + str(if_count) + "( input clk, input start, input reset, output valid, output busy, "+define_a_b
            
            # Input
            for j in range (0, len(combined_input_names)):
                if(j<len(combined_input_names)-1):
                    if(combined_input_names[j] ==operands[0] or combined_input_names[j] ==operands[1] ):
                        sddss=0
                    else:
                        in_out_state = in_out_state + "input [31:0]" + combined_input_names[j] + ", "
                
                else:
                    if(combined_input_names[j] ==operands[0] or combined_input_names[j] ==operands[1] ):
                        sddss=0
                        comma = 1
                    else:
                        in_out_state = in_out_state + "input [31:0]" + combined_input_names[j]
                        comma = 0
            
            
            # Output
            
            
            if(len(output_if_else_self_gen)>0 and len(combined_input_names)>0):
                if(comma ==0):
                    in_out_state = in_out_state + ", "
            else:
                in_out_state = in_out_state + ") "
            for j in range (0, len(output_if_else_self_gen)):
                temp_output_name = output_if_else_self_gen[j]
                #for j in range (0, len(output_if_else_self_gen)):
                    # if(temp_output_name == combined_output_names[j]):
                    #     if(combined_output_names[j] != 1):
                    #         temp_output_name = temp_output_name + "_gen_new_" + str(combined_output_names[j])
                
                if(j<len(output_if_else_self_gen)-1):
                    in_out_state = in_out_state + "output [31:0]" + temp_output_name + ", "
                else:
                    in_out_state = in_out_state + "output [31:0]" + temp_output_name + "); \n"
            
            
            
            

            
            
            
            
            
            with open(combined_file_name, 'r') as file: 
                data = file.readlines() 
              
            #print(data) 
            data[0] = in_out_state
            data.append("\n\nendmodule")

            
            
            with open(combined_file_name, 'w') as file: 
                file.writelines(data) 
            
            
            
            
            set5 = set(Verilog_IF_Else_Gen.if_input_names)
            set6 = set(Verilog_IF_Else_Gen.else_input_names)
            combined_input_names_pure = list(set5.union(set6))
            
            
            
            
            #set7 = set(lib_in_out_names.result_names_if)
            #set8 = set(lib_in_out_names.result_names_else)
            combined_output_names_pure = lib_in_out_names.result_names_if
            combined_output_names_pure_top = []
            
            for j in range (0, len(combined_output_names_pure)):
                combined_output_names_pure_top.append(result_name_adder(combined_output_names_pure[j], file_name))
                #print(result_name_adder(combined_output_names_pure[j]))
            
            
            f = open(file_name, "a")
            # Comments
            f.write("\t//Proceed with one function if calculation.\n")
            
            f.write("\twire "+ start_line_name_else +";\n" + 
                    "\twire "+ valid_line_name_else +";\n" +
                    "\twire "+ busy_line_name_else +";\n"        
                         )
            
            f.write("\tif_else_self_gen_"+ str(if_count) +" "+name_comp_else +"(" +  
                    " clk, " + start_line_name_else + ", reset, " +
                    valid_line_name_else + "," + busy_line_name_else + ", "
                    
                         )
            
            
            
            if(operands[0].isnumeric()):
                a_part_1 = ""
            else:
                a_part_1 = input_name_decider(operands[0])  + ", " 
            
            if(operands[1].isnumeric()):
                b_part_1 = ""
            else:
                b_part_1 =  input_name_decider(operands[1]) + ", " 
            
            
            define_a_b_1 = a_part_1 + b_part_1
           
            
            f.write(define_a_b_1)
            
            previous_comma = 0
            for j in range(0, len(combined_input_names_pure)):
                # Write the input name into the top file
                #previous_comma = 0
                f = open(file_name, "a")
                if(combined_input_names_pure[j] ==operands[0] or combined_input_names_pure[j] ==operands[1] ):
                    dsdd= 0
                    f.close()
                    if(j==len(combined_input_names_pure)-1):
                        f = open(file_name, "a")
                        f.write(" ")
                        f.close()
                        previous_comma = 1
                else:
                    f.write(input_name_decider(combined_input_names_pure[j]))
                
                    f.close()
                    #print(combined_input_names_pure[j])
                    # Write the comma after input names
                    if(j<=len(combined_input_names_pure)-2):
                        f = open(file_name, "a")
                        f.write(", ")
                        f.close()
                        #previous_comma = 1
                    #else:
                        #previous_comma = 0
            
            
            # set7 = set(lib_in_out_names.result_names_if)
            # set8 = set(lib_in_out_names.result_names_else)
            # combined_output_names_pure = list(set5.union(set6))
            
            
            
            
            # Proceed with the output names
            if(len(combined_output_names_pure_top) != 0):
                if(  previous_comma ==0):
                    f = open(file_name, "a")
                    f.write(", ")
                    f.close()
                for j in range(0, len(combined_output_names_pure_top)):
                    # Write the input name into the top file
                    f = open(file_name, "a")
                    f.write(combined_output_names_pure_top[j])
                    f.close()
                    
                    # Write the comma after input names
                    if(j<=len(combined_output_names_pure_top)-2):
                        f = open(file_name, "a")
                        f.write(", ")
                        f.close()
            f = open(file_name, "a")
            f.write(");\n\n\n\n\n\n")
            f.close()
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            if_count = if_count + 1
        
        
        
        
        
        
        
        
        
        
        else:
            
            match operator:
                case 0:
                    
                    do = 0
                    
                case 1:
                    name_comp = "addition_HDL_" + str(add_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " + " +  input_name_1 + "\n"
                                 )
                    
                    
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\taddition_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    
                    f.close()
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    add_count = add_count + 1
                
                
                
                
                
                
                
                # -
                case 2:
                    name_comp = "subtraction_HDL_" + str(substract_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " - " +  input_name_1 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tSubtraction_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    substract_count = substract_count + 1           
                
                
                
                
                
                
                
                
                
                # *
                case 3:
                    name_comp = "mul_HDL_" + str(mul_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " * " +  input_name_1 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\tmul_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    mul_count = mul_count + 1
            
            
            
            
            
            
            
            
            
            
            
                # /
                case 4:
                    name_comp = "division_HDL_" + str(div_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " / " +  input_name_1 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tDivision_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    div_count = div_count + 1
                
                
                
                
                
                
                
                
                
                # Power
                case 5:
                    name_comp = "power_HDL_" + str(power_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = Pow("
                            + input_name_0 + ", " +  input_name_1 + ")\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tPower_PN "+ name_comp +"( clk, " + input_name_0 
                            + ", ("  + input_name_1 + ">>16), " + result_name_ + 
                            ", " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    power_count = power_count + 1
                
                
                
                
                
                
                
                
                
                
                # Log
                case 6:
                    name_comp = "log_HDL_" + str(log_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = log"
                            + input_name_0 + " ( " +  input_name_1 + ")\n"
                                 )
                    
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tlog_inout "+ name_comp + "( " + start_line_name
                            + ", clk, reset, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            "," + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    
                    log_count = log_count + 1
                
                
                
                
                
                
                
                # SQRT
                case 7:
                    name_comp = "sqrt_HDL_" + str(sqrt_count)
                    
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    #input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = sqrt( "
                            + input_name_0 + " )\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tsqrt "+ name_comp + " ( clk, " + input_name_0 +
                            ", " + start_line_name
                            + ", reset, " + result_name_ + 
                            ", " + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sqrt_count = sqrt_count + 1
                
                
                
                
                
                
                # SinCosTan
                case 8:
                    name_comp = "sincostan_HDL_" + str(sincostan_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0])
                    #input_name_1 = input_name_decider(operands[1])                   
                    result_name_0 = result_name_adder(results[0], file_name)
                    result_name_1 = result_name_adder(results[1], file_name)
                    result_name_2 = result_name_adder(results[2], file_name)
                    
                    f = open(file_name, "a")
                    
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_0 + " = sin("
                            + input_name_0 + ")\n \t//" + result_name_1 + " = cos("
                            + input_name_0 + ")\n \t//"+ result_name_2 + " = tan("
                            + input_name_0 + ")\n "
                                 )
                    
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\ttan_inout "+ name_comp + " ( clk, " + input_name_0 + 
                            ", " + result_name_0 + ", " + result_name_1 + ", " 
                            + result_name_2 + ", " + start_line_name
                            + ", reset, " + valid_line_name +
                            ", " + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sincostan_count = sincostan_count + 1
                
                
                
                
                
                
                
                
                
                
                # Value / Delay
                case 9:
                    name_comp = "Value_HDL_" + str(value_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    if(operands[0] ==results[0]):
                        input_name_0 = result_name_adder(operands[0], file_name)
                        result_name_ = result_name_adder(results[0], file_name)
                        
                    else:
                        input_name_0 = input_name_decider(operands[0])
                        
                        result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tdelay "+ name_comp + " (" + start_line_name
                            +", clk, reset, " + input_name_0 + 
                            ", " + result_name_ + ", " + busy_line_name 
                            +", " + valid_line_name +
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    previous_valid = valid_line_name
                    if(i == counter_all):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    
                    value_count = value_count + 1
                
                case _:
                    print("No such function")




    f = open(file_name, "a")
    f.write("endmodule")
    f.close()
    input_output_print_top(file_name)