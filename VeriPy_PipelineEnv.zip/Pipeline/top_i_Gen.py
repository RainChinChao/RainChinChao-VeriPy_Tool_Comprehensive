from Add_Into_Structure_Array import Add_Into_Structure_Array
import itertools
from Template import Max_number_operands
from Template import Max_number_results
def top_i_V(output_0,input_0,input_1,input_2,input_3):
	results = list(itertools.repeat('0', Max_number_results))
	inputs = list(itertools.repeat('0', Max_number_results))
	results[0] = output_0
	inputs[0] = input_0
	inputs[1] = input_1
	inputs[2] = input_2
	inputs[3] = input_3

	operator_num =1005
	number_of_operands = 4
	number_of_results =1
	Add_Into_Structure_Array(results, inputs, operator_num, number_of_operands, number_of_results, 8)