# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 13:37:36 2024

@author: elx22yz
"""

''' 29/04/2024
    Version 0.0.1
    This is the function to print input/ output names to the first line of the
    top file. However, as we have already generate the top file, we need to 
    use a specific copy/paste method to update
    
'''
import lib_para
import Verilog_Generation
import lib_in_out_names
def input_output_print_top(file_name):
    in_out_state = "module top( "
    
    # Input
    for i in range (0, len(lib_para.input_names)):
        if(i<len(lib_para.input_names)-1):
            in_out_state = in_out_state + "input [31:0]" + lib_para.input_names[i] + ", "
        else:
            in_out_state = in_out_state + "input [31:0]" + lib_para.input_names[i]
    
    
    # Output
    if(len(lib_para.output_names)>0 and len(lib_para.input_names)>0):
        in_out_state = in_out_state + ", "
    else:
        in_out_state = in_out_state + ") "
    for i in range (0, len(lib_para.output_names)):
        temp_output_name = lib_para.output_names[i]
        for j in range (0, len(lib_in_out_names.result_names)):
            if(temp_output_name == lib_in_out_names.result_names[j]):
                if(lib_in_out_names.result_name_no[j] != 1):
                    temp_output_name = temp_output_name + "_gen_new_" + str(lib_in_out_names.result_name_no[j])
        
        if(i<len(lib_para.output_names)-1):
            in_out_state = in_out_state + "output [31:0]" + temp_output_name + ", "
        else:
            in_out_state = in_out_state + "output [31:0]" + temp_output_name + ", input clk, input start, output valid, output busy, input reset); \n"
    
    
    
    
    
    with open(file_name, 'r') as file: 
        data = file.readlines() 
      
    #print(data) 
    data[0] = in_out_state
    
    # f = open(file_name, "w")
        
    # f.write(" ")
        
    # f.close()
    
    
    with open(file_name, 'w') as file: 
        file.writelines(data) 