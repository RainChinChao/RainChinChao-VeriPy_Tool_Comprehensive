# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 15:34:20 2024

@author: elx22yz
"""

def Time_consumption(void):
    import real_binary_tree_est_multiDelay
    import lib_para
    print("Time consumption of each results:")
    for i in range(0, len(lib_para.output_names)):
        print("top_" + lib_para.output_names[i])
        print("time: " + str(real_binary_tree_est_multiDelay.algorithm_total_delay_array[i])
              + " cycles.")
    
    print("This is the end of the time consumption reports.")