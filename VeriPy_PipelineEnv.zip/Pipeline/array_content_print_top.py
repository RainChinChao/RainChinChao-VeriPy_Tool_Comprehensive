# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 14:33:08 2024

@author: elx22yz
"""






import lib_reg
def array_content_print_top(file_name):
    
    
    
    
    for i in range (0, lib_reg.reg_array_counter):
        
        
        
        f = open(file_name, "a")
        array_name_now = lib_reg.reg_array_names[i]
        array_size_now = len(lib_reg.reg_array_list[i])
        
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n")
        f.write("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t// Generate the array " + array_name_now + "["
                + str(array_size_now) +"]\n")
        
        
        # f.write("\treg [31:0]array_" + array_name_now +
        #         "["+ str(array_size_now-1)+ ":0]" 
        #         +";\n"        
        #              )
        
        f.close()
        
        for j in range(0, array_size_now):
            
            
            #print("array_print_top")
            
            f = open(file_name, "a")
            
            reg_name = "\treg [31:0] array_" + array_name_now + "_" + str(j) 
            
            reg_state = reg_name + " = " + str(lib_reg.reg_array_list[i][j]) + "; \n"
                
            f.write(reg_state)
            
            
            wire_name = " array_" + array_name_now + "_wire_"+str(j)
                
            wire_state = "\twire [31:0]" + wire_name+";\n"
                
            f.write(wire_state)
                
            f.write("\tassign "+ wire_name + " = array_" + array_name_now
                    + "_" + str(j) + ";\n"        
                             )
                
            f.close()
        f = open(file_name, "a")
        f.write("\t// End the array " + array_name_now + "["
                + str(array_size_now) +"]\n\n\n\n")
        f.close()