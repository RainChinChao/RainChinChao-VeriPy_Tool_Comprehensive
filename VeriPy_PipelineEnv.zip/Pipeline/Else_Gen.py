# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 14:53:34 2024

@author: elx22yz
"""

''' 07/03/2024
    Version 0.0.1
    This is the function to generate Else into a new record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''


from Add_Into_Structure_Array import Add_Into_Structure_Array
import itertools
from Template import Max_number_operands     
from Template import Max_number_results
from Template import dt
import lib_para

def Else_V(void):
    
    lib_para.Else_counter = lib_para.Else_counter + 1
    lib_para.Address_counter_else = -1
    new_If_counter = str(lib_para.If_counter)
    # determination = "If_deter_" + new_If_counter + " = 0"
    # if_verilog_file_name = 'if_V' + new_If_counter + '.v'
    # f = open(if_verilog_file_name, "a")
    # f.write( "\telse begin" +
    #         "\n\t\t" +
    #         determination +
    #         "\n\tend\nend")
    # f.close()
    results = list(itertools.repeat('0', Max_number_results))
    inputs = list(itertools.repeat('0', Max_number_operands))
    # For if/else condition
    operator_num = 10
    number_of_operands = 0
    number_of_results = 0
    
    #Add_Into_Structure_Array(results, inputs, operator_num, number_of_operands, 
                                 #number_of_results, 1)