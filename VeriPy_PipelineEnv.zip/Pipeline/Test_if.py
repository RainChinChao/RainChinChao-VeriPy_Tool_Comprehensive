# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 14:33:47 2024

@author: elx22yz
"""
''' 18/03/2024
    Version 0.0.1
    This is the function the main function that calls all kinds of generation 
    functions like Addition_V, Multi_V, etc.
'''

import numpy as np
from Template import dt
#from Addition_Gen import Addition_V
from SinCosTan_Gen import SinCosTan_V
from Addition_new import Addition_V
from Logarithm_Gen import Logarithm_V
from Division_Gen import Division_V
from Multiplication_Gen import Multiplication_V
from Power_Gen import Power_V
from Sqrt_Gen import Sqrt_V
from Subtraction_Gen import Subtraction_V
from Value_Gen import Value_V
from Addition_IF_Gen import Addition_IF_V
from If_Gen import If_V
from Else_Gen import Else_V
import lib_para
lib_para.Address_counter = -1
# Initialize Address_counter = 0


'''
Addition_V1('c', 'a', 'b')
Addition_V1('f', 'a', 'c')
Addition_V1('g', 'a', 'f')
Addition_V1('h', 'f', 'c')
Addition_V1('x', 'y', 'z')
'''


Addition_V('c', 'a', 'b')
SinCosTan_V('x', 'y', 'z', 'c')
Addition_V('d', 'x', 'a')

Addition_V('e', 'd', 'y')
Addition_V('f', 'e', 'z')
Addition_V('h', 'f', 'g')


If_V("a==0")
Addition_IF_V('c', 'a', 'b')
Addition_IF_V('d', 'c', 'x')
Addition_IF_V('h', 'e', 'd')
Else_V("a==0")



import lib_para
binary_tree_main = lib_para.Eq_record
counter_all = lib_para.Address_counter
binary_tree_if = lib_para.Eq_record_if_1
counter_if = lib_para.Address_counter_if