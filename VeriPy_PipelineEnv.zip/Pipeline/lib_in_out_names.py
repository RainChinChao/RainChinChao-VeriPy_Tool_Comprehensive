# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:36:03 2024

@author: elx22yz
"""




result_names = []
result_name_no = []
result_names_counter = 0


result_names_counter_if = 0
result_name_no_if = []
result_names_if = []


result_names_counter_else = 0
result_name_no_else = []
result_names_else = []







# def print_res(a):
#     for i in range (0, result_names_counter):
        
#         f = open("result.txt", "a")
        
#         f.write("\t"+ result_names[i] +" : " + str(result_name_no[i]) +";\n"                                
#                      )
#         #f.write("\tassign "+ new_result_name + "=" +na  +";\n"   )
#         f.close()
#     f = open("result.txt", "a")    
#     f.write("\n\n\n"  )
#     f.close()