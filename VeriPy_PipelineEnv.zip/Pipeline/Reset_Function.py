# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 15:18:24 2024

@author: elx22yz
"""

'''
    Reset function:
        To reset all the things including Updated function names, numbers and 
        resources

'''


def Reset_Function(void):
    f = open("New_function_names.py", "w")  
    f.write("\nNew_function_names = []")
    f.close()
    
    f = open("update_function_number.py", "w")  
    f.write("update_function_number = " + str(1000))
    f.close()
    
    
    f = open("lib_resource_newfun.py", "w")  
    f.write("LUT_array = []\n"
            +"FF_array = []\n"
            +"DSP_array = []\n"
            +"BRAM_array = []")
    f.close()

    

Reset_Function("")