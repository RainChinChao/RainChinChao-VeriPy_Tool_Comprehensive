# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 15:06:41 2024

@author: elx22yz
"""
''' 29/04/2024
    Version 0.0.1
    This is the function to print same name array. For example, if developer
    need a A[100], we will connnect this reg A[100] to 100 wires.
    reg [100]A[31:0];
    wire 1
    
'''
import lib_para


def array_print_top(file_name):
    
    
    
    
    for i in range (0, len(lib_para.array_names)):
        
        
        
        f = open(file_name, "a")
        array_name_now = lib_para.array_names[i]
        array_size_now = lib_para.array_sizes[i]
        
        f.write("\n\n\n\t// Generate the array " + array_name_now + "["
                + str(array_size_now) +"]\n")
        
        
        f.write("\treg [31:0]array_" + array_name_now +
                "["+ str(array_size_now-1)+ ":0]" 
                +";\n"        
                     )
        
        f.close()
        
        for j in range(0, array_size_now):
            
            
            #print("array_print_top")
            
            f = open(file_name, "a")
                
            wire_name = " array_" + array_name_now + "_wire_"+str(j)
                
            wire_state = "\twire [31:0]" + wire_name+";\n"
                
            f.write(wire_state)
                
            f.write("\tassign "+ wire_name + " = array_" + array_name_now
                    + "["+str(j)+"]"  
                        +";\n"        
                             )
                
            f.close()
        f = open(file_name, "a")
        f.write("\t// End the array " + array_name_now + "["
                + str(array_size_now) +"]\n\n\n\n")
        f.close()