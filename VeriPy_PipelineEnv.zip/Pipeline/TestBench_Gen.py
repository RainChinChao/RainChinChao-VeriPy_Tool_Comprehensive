# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 09:50:05 2024

@author: elx22yz
"""

''' 14/06/2024
    Version 0.0.1
    This is the function to generate the testbench for the design according to 
    the input output numbers using random function.
    
'''
import lib_para
#import Verilog_Generation
import lib_in_out_names



def TestBench_Gen(a):
    
    
       
    
    for ii in range (0, len(lib_para.output_names)):
        
        
        
        
        file_name = a + lib_para.output_names[ii] + "_TestBench.v"
        
        
        
        
        f = open(file_name, "w")   
        
        
        
        
        f.write("module test();") 
        f.write("\treal i;") 
        f.write("\n\treg clk=1;\n\treg reset = 0;\n\talways #5 clk = !clk;\n"  )
        f.write("\n\treg start=1;\n\twire busy;\n\twire valid;\n"  )
        f.close()
        
        
        
        input_name_store = []
        
        in_out_state = str(a) + "_" + lib_para.output_names[ii] + "_with_control " + str(a) + "_" + lib_para.output_names[ii] + "1( "
        # Input
        for i in range (0, len(lib_para.input_names)):
            if(i<len(lib_para.input_names)-1):
                in_out_state = in_out_state + lib_para.input_names[i] + ", "
                
                f = open(file_name, "a")
                f.write("\treg [31:0]" + lib_para.input_names[i] +";\n" )
                f.close()
                
                input_name_store.append(lib_para.input_names[i])
            else:
                in_out_state = in_out_state + lib_para.input_names[i]
                
                
                f = open(file_name, "a")
                f.write("\treg [31:0]" + lib_para.input_names[i] +";\n" )
                f.close()
                input_name_store.append(lib_para.input_names[i])
            
        # Output
        
        for i in range (0, len(lib_para.output_names)):
            f = open(file_name, "a")
            f.write("\twire [31:0]" + lib_para.output_names[i] +";\n" )
            f.close()    
        
        
        
        f = open(file_name, "a")
        f.write("\t" + in_out_state + ", ")
        
        
        if(len(lib_para.output_names)==1):
            f.write(lib_para.output_names[0])
        else:
            for i in range (0, len(lib_para.output_names)):
                if(i==0):
                    f = open(file_name, "a")
                    f.write(lib_para.output_names[i])
                else:
                    f = open(file_name, "a")
                    f.write(", " + lib_para.output_names[i])
        f.write(", clk, reset, start, valid, busy); \n")
        f.close()
        
        
        # in_out_state = in_out_state +", "+ out_names + ", clk, reset, start, valid, busy); \n"
           
            
        f = open(file_name, "a")
        #f.write("\t" + in_out_state )
        
        
        f.write("\n\tinitial begin\n")
        f.write("\t\tfor(i = 0; i < 10000; i=i+1)begin\n")
        for i in range (0, len(input_name_store)):
            f.write("\t\t\t" + input_name_store[i] + "=$random;\n")
        
        f.write("\t\tend\n")
        f.write("\tend\n")
        f.write("endmodule")
        f.close()

    
   