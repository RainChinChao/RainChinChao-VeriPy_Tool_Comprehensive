# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 10:38:40 2024

@author: elx22yz
"""
''' 05/06/2024
    Version 0.0.1
    This is the function to find the result address in the binary tree.
    
'''



import lib_para
import IfElse_Arrays


def result_address_finder(result_name):
    
    binary_tree_main = lib_para.Eq_record
    counter_all = lib_para.Address_counter
    
    # Find branches in different result
    
    
    #for i in range (0, len(lib_para.output_names)):
    
        
    # Default the address
    address_current_output = -1
    # Find the last equation of current result
    
    
    # Find the last equation in main binary tree
    for i in range (counter_all + 1, 0, -1):

        results_array = binary_tree_main[i]['result_name_array']
        no_results = binary_tree_main[i]['number_of_results']
        
        
        # Find out the current result content
        for k in range (0, no_results):
            result_in_binary = results_array[k]
    
            if(result_in_binary == result_name):
                address_current_output = i
                    
                    
                    
                break
        
        
    # When the result is in the if/else binary tree
    if(address_current_output == -1):
            
        # This is to record previous address in If array
        for i in range(0, lib_para.If_counter):
            if(int(IfElse_Arrays.if_delay[i])>0):
                for j in range(0, IfElse_Arrays.if_delay[i]):
                    num_of_pre_result = IfElse_Arrays.if_array[i][j]['number_of_results']
                    for l in range(0, num_of_pre_result):
                        if(IfElse_Arrays.if_array[i][j]['result_name_array'][l] == result_name): 
                            previous_addresses_if = j + IfElse_Arrays.start_address_if[i] + 1
            
            
        # This is to record previous address in Else array
        for i in range(0, lib_para.If_counter):
            if(int(IfElse_Arrays.else_delay[i])>0):
                for j in range(0, IfElse_Arrays.else_delay[i]):
                    num_of_pre_result = IfElse_Arrays.else_array[i][j]['number_of_results']
                    for l in range(0, num_of_pre_result):
                        if(IfElse_Arrays.else_array[i][j]['result_name_array'][l] == result_name): 
                            previous_addresses_else = j + IfElse_Arrays.start_address_if[i] + 1
        address_current_output = [previous_addresses_if, previous_addresses_else]
            
            
    return address_current_output
            
            
            