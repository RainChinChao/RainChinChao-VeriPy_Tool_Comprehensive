# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 10:04:24 2024

@author: elx22yz
"""
''' 06/03/2024
    Version 0.0.1
    This is the function to generate addition into the record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''

from Add_Into_Structure_Array import Add_Into_Structure_Array
import itertools
from Template import Max_number_operands     
from Template import Max_number_results

def Addition_V(c, a, b):
      
    results = list(itertools.repeat('0', Max_number_results))
    results[0] = c
    inputs = list(itertools.repeat('0', Max_number_operands))
    inputs[0] = a
    inputs[1] = b  
    operator_num = 1
    number_of_operands = 2
    number_of_results = 1
    
    Add_Into_Structure_Array(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)
