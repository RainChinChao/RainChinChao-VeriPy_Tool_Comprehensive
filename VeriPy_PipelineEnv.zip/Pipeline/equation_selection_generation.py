# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 14:35:52 2024

@author: elx22yz
"""

''' 05/06/2024
    Version 0.0.1
    This is the function to generate the equation through the operator stored 
    in address.
'''

import lib_para
import lib_in_out_names

import lib_pipe_BinaryTree


def result_name_adder(na, file_name):
                 
    f = open(file_name, "a")    
    f.write("\twire [31:0]" + na + ";\n")   
    f.close()
        
   
    return na



def input_name_decider(na, file_name):
    
    # When there is nothing in the array
    if(lib_in_out_names.input_names_counter == 0):
        lib_in_out_names.input_names.append(str(na))
        lib_in_out_names.input_name_no.append(1)
        lib_in_out_names.input_names_counter = 1
        new_result_name = na
        
        f = open(file_name, "a")
        f.write("\twire [31:0]" + new_result_name + "_gen_new;\n")
        f.close()
    
    # When there are already some records inside the array
    else:
        
        # Flag to boolean if there is the same name recorded before
        flag = 0
        for j in range (0, lib_in_out_names.input_names_counter):
            if(lib_in_out_names.input_names[j] == str(na)):
                flag = 1
                temp_j=j
        
        # When there is the same name record before
        if(flag == 1):

            lib_in_out_names.input_name_no[temp_j] = lib_in_out_names.input_name_no[temp_j] + 1
            new_result_name = str(na) + "_gen_new_" + str(lib_in_out_names.input_name_no[temp_j])

            f = open(file_name, "a")
            f.write("\twire [31:0]" + new_result_name + ";\n")
            f.close()
            
        # When it is the first time to record this name   
        else:
            lib_in_out_names.input_names.append(str(na))
            lib_in_out_names.input_name_no.append(1)
            lib_in_out_names.input_names_counter = lib_in_out_names.input_names_counter + 1
            new_result_name = na
            
            f = open(file_name, "a")            
            f.write("\twire [31:0]" + new_result_name + "_gen_new;\n")
            f.close()

    return new_result_name


   





















# Address is to print the info
# Level for which level this operation is in
def equation_selection_generation(address, file_name, level):
    
    binary_tree_main = lib_para.Eq_record
    
    operands = binary_tree_main[address]['operand_name_array']
    no_operands = binary_tree_main[address]['number_of_operands']        
    operator = binary_tree_main[address]['operator'] 
    results = binary_tree_main[address]['result_name_array']
    no_results = binary_tree_main[address]['number_of_results']
    previous_addresses = binary_tree_main[address]['previous_address']
    no_previous_adresses = binary_tree_main[address]['no_of_previous_address']
    
    
    
    
    
    
    
    
    
    lib_pipe_BinaryTree.if_count = 0
    lib_pipe_BinaryTree.add_count = 0
    lib_pipe_BinaryTree.substract_count = 0
    lib_pipe_BinaryTree.mul_count = 0
    lib_pipe_BinaryTree.div_count = 0
    lib_pipe_BinaryTree.power_count = 0
    lib_pipe_BinaryTree.log_count = 0
    lib_pipe_BinaryTree.sqrt_count = 0
    lib_pipe_BinaryTree.sincostan_count = 0
    lib_pipe_BinaryTree.value_count = 0
    
    
    
    
    
    
    
    match operator:
        
        # case 0 means it is in If/Else array
        case 0:
            
            do = 0
            
        case 1:
            name_comp = "addition_HDL_" + str(lib_pipe_BinaryTree.add_count)
            
            
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            
            
            
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " + " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            
            f.write("\taddition_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, " + start_line_name + ", reset, " +
                    valid_line_name + "," + busy_line_name
                    + ");\n"
                         )
            
            #f.write("\tassign "+ start_line_name + " = " + previous_valid + ";\n\n\n"        
            #             )
            
            f.close()
            
            

            
            
            lib_pipe_BinaryTree.add_count = lib_pipe_BinaryTree.add_count + 1
        
        
        
        
        
        
        
        # -
        case 2:
            name_comp = "subtraction_HDL_" + str(lib_pipe_BinaryTree.substract_count)
            
            
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " - " +  input_name_1 + "\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tSubtraction_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, " + start_line_name + ", reset, " +
                    valid_line_name + "," + busy_line_name
                    + ");\n"
                         )
            

            f.close()
            
            

            
            
            
            
            lib_pipe_BinaryTree.substract_count = lib_pipe_BinaryTree.substract_count + 1           
        
        
        
        
        
        
        
        
        
        # *
        case 3:
            name_comp = "mul_HDL_" + str(lib_pipe_BinaryTree.mul_count)
            

            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " * " +  input_name_1 + "\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            
            f.write("\tmul_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, " + start_line_name + ", reset, " +
                    valid_line_name + "," + busy_line_name
                    + ");\n"
                         )
                   

            f.close()
            

            
            
            lib_pipe_BinaryTree.mul_count = lib_pipe_BinaryTree.mul_count + 1
    
    
    
    
    
    
    
    
    
    
    
        # /
        case 4:
            name_comp = "division_HDL_" + str(lib_pipe_BinaryTree.div_count)
            
            
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " / " +  input_name_1 + "\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tDivision_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, " + start_line_name + ", reset, " +
                    valid_line_name + "," + busy_line_name
                    + ");\n"
                         )
            
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
            
            

            
            
            lib_pipe_BinaryTree.div_count = lib_pipe_BinaryTree.div_count + 1
        
        
        
        
        
        
        
        
        
        # Power
        case 5:
            name_comp = "power_HDL_" + str(lib_pipe_BinaryTree.power_count)
            
          
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = Pow("
                    + input_name_0 + ", " +  input_name_1 + ")\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tPower_PN "+ name_comp +"( clk, " + input_name_0 
                    + ", ("  + input_name_1 + ">>16), " + result_name_ + 
                    ", " + start_line_name + ", reset, " +
                    valid_line_name + "," + busy_line_name
                    + ");\n"
                         )
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
            
           
            
            
            lib_pipe_BinaryTree.power_count = lib_pipe_BinaryTree.power_count + 1
        
        
        
        
        
        
        
        
        
        
        # Log
        case 6:
            name_comp = "log_HDL_" + str(lib_pipe_BinaryTree.log_count)
            
          
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            input_name_1 = input_name_decider(operands[1], file_name)
            result_name_ = result_name_adder(results[0], file_name)
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = log"
                    + input_name_0 + " ( " +  input_name_1 + ")\n"
                         )
            
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tlog_inout "+ name_comp + "( " + start_line_name
                    + ", clk, reset, " + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    "," + busy_line_name + ", " + valid_line_name 
                    + ");\n"
                         )
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
            
            
           
            
            
            
            lib_pipe_BinaryTree.log_count = lib_pipe_BinaryTree.log_count + 1
        
        
        
        
        
        
        
        # SQRT
        case 7:
            name_comp = "sqrt_HDL_" + str(lib_pipe_BinaryTree.sqrt_count)
            
          
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            
            input_name_0 = input_name_decider(operands[0], file_name)
            #input_name_1 = input_name_decider(operands[1])
            result_name_ = result_name_adder(results[0], file_name)
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = sqrt( "
                    + input_name_0 + " )\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tsqrt "+ name_comp + " ( clk, " + input_name_0 +
                    ", " + start_line_name
                    + ", reset, " + result_name_ + 
                    ", " + busy_line_name + ", " + valid_line_name 
                    + ");\n"
                         )
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
            
            
            
         
            lib_pipe_BinaryTree.sqrt_count = lib_pipe_BinaryTree.sqrt_count + 1
        
        
        
        
        
        
        # SinCosTan
        case 8:
            name_comp = "sincostan_HDL_" + str(lib_pipe_BinaryTree.sincostan_count)
           
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            input_name_0 = input_name_decider(operands[0], file_name)
            #input_name_1 = input_name_decider(operands[1])                   
            result_name_0 = result_name_adder(results[0], file_name)
            result_name_1 = result_name_adder(results[1], file_name)
            result_name_2 = result_name_adder(results[2], file_name)
            
            f = open(file_name, "a")
            
            
            # Comments
            f.write("\t//Proceed with " + result_name_0 + " = sin("
                    + input_name_0 + ")\n \t//" + result_name_1 + " = cos("
                    + input_name_0 + ")\n \t//"+ result_name_2 + " = tan("
                    + input_name_0 + ")\n "
                         )
            
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\ttan_inout "+ name_comp + " ( clk, " + input_name_0 + 
                    ", " + result_name_0 + ", " + result_name_1 + ", " 
                    + result_name_2 + ", " + start_line_name
                    + ", reset, " + valid_line_name +
                    ", " + busy_line_name
                    + ");\n"
                         )
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
            
           
            lib_pipe_BinaryTree.sincostan_count = lib_pipe_BinaryTree.sincostan_count + 1
        
        
        
        
        
        
        
        
        
        
        # Value / Delay
        case 9:
            name_comp = "Value_HDL_" + str(lib_pipe_BinaryTree.value_count)
           
            
            start_line_name = "start_" + name_comp
            valid_line_name = "valid_" + name_comp 
            busy_line_name = "busy_" + name_comp
            
            
            if(operands[0] ==results[0]):
                input_name_0 = result_name_adder(operands[0], file_name)
                result_name_ = result_name_adder(results[0], file_name)
                
            else:
                input_name_0 = input_name_decider(operands[0], file_name)
                
                result_name_ = result_name_adder(results[0], file_name)
            
            # store the line information
            lib_pipe_BinaryTree.Level_valid_array[level].append(valid_line_name)
            lib_pipe_BinaryTree.Level_start_array[level].append(start_line_name)
            
            f = open(file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + "\n"
                         )
            
            f.write("\twire "+ start_line_name +";\n" + 
                    "\twire "+ valid_line_name +";\n" +
                    "\twire "+ busy_line_name +";\n"        
                         )
            f.write("\tdelay "+ name_comp + " (" + start_line_name
                    +", clk, reset, " + input_name_0 + 
                    ", " + result_name_ + ", " + busy_line_name 
                    +", " + valid_line_name +
                    + ");\n"
                         )
            f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                         )
            f.close()
            
          
            
            
            lib_pipe_BinaryTree.value_count = lib_pipe_BinaryTree.value_count + 1
        
        case _:
            print("No such function")
    
    
    
    
    
    
    