# -*- coding: utf-8 -*-
"""
Created on Tue Mar  4 15:09:17 2025

@author: elx22yz
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 15:09:27 2024

@author: elx22yz
"""



import numpy as np
from Template import dt
#from Addition_Gen import Addition_V
from SinCosTan_Gen import SinCosTan_V
from Addition_Gen import Addition_V
from Logarithm_Gen import Logarithm_V
from Division_Gen import Division_V
from Multiplication_Gen import Multiplication_V
from Power_Gen import Power_V
from Sqrt_Gen import Sqrt_V
from Subtraction_Gen import Subtraction_V
from Value_Gen import Value_V
from Addition_IF_Gen import Addition_IF_V
from Addition_Else_Gen import Addition_Else_V
from If_Gen import If_V
from Else_Gen import Else_V
import lib_para
from End_IfElse_Gen import End_IfElse_V
from Multiplication_IF_Gen import Multiplication_IF_V
from Multiplication_Else_Gen import Multiplication_Else_V
import IfElse_Arrays
lib_para.Address_counter = -1
# Initialize Address_counter = 0
from number_to_hex_Input import number_to_hex
from array_define_Gen import array_define
from output_define import output_define
from input_define import input_define
from array_define_content import array_define_content


for i in range (0, 2):
    in_a = "x_" + str(i)
    input_define(in_a)



in_b = "y_0"
input_define(in_b)

output_define("delta_0")



weights = [number_to_hex(1), number_to_hex(0)]

array_define_content("weights", weights)












Multiplication_V( 'XW00', 'x_0', 'array_weights_wire_0' )
Multiplication_V( 'XW10', 'x_1', 'array_weights_wire_1' )


Addition_V( 'net_in_0', 'XW00', 'XW10')

Multiplication_V( 'out_t_0', 'net_in_0', number_to_hex(0.5) )
Addition_V( 'out_0', 'out_t_0', number_to_hex(0.5))
Addition_V( 'out_1', 'out_t_0', number_to_hex(0))


Subtraction_V( 'error_0', 'y_0', 'out_0')

Subtraction_V( 'sub_out_0', 'out_0', number_to_hex(1))

Multiplication_V( 'sig_deri_0', 'sub_out_0', 'out_1')

Multiplication_V( 'delta_0', 'sig_deri_0', 'error_0')




from real_binary_tree_est_multiDelay import real_binary_tree_est
real_binary_tree_est("MAC_16")