# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 10:23:19 2024

@author: elx22yz
"""

''' 19/03/2024
    Version 0.0.1
    This is the library for storing if/else strucutre arrays.
    
'''



import numpy as np
from Template import dt
from Template import Max_number_operands     
from Template import Max_number_results 
from Template import Max_no_previous_addreeses
Address_counter = -1

import itertools

Max_no_IF = 1000
# Define the maximum no of equation inside if/else
#Max_in_IF_equ=10000


Initial_inputs_names = list(itertools.repeat('0', Max_number_operands))
Initial_results_names = list(itertools.repeat('0', Max_number_results))
Initial_previous_addresses = list(itertools.repeat(-1, Max_no_previous_addreeses))
Initial_no_of_previous_addresses = list(itertools.repeat('0', Max_number_operands))


Record_if = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses,Initial_no_of_previous_addresses, 0)],          
                        dtype=dt)



Record_else = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses,Initial_no_of_previous_addresses, 0)],          
                        dtype=dt)



if_array = [Record_if.copy() for _ in range(Max_no_IF)]

else_array = [Record_if.copy() for _ in range(Max_no_IF)]


if_delay=list(itertools.repeat('0', Max_no_IF))
else_delay=list(itertools.repeat('0', Max_no_IF))

start_address_if = list(itertools.repeat('0', Max_no_IF))

if_results_names = []
else_results_names = []

# Record_if_1 = np.array([("Initial_inputs_names", 0, 0, "Initial_results_names", 0, 
#                         Initial_previous_addresses, 0)],          
#                         dtype=dt)
# Record_if_1_l = [Record_if_1.copy() for _ in range(3)]

# if_array[0] = Record_if_1_l





