# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 10:09:13 2024

@author: elx22yz
"""

''' 06/03/2024
    Version 0.0.1
    This is the function to generate any functions into the record structure 
    array specially in if/else
    
'''

import numpy as np
from Template import dt 
from Template import Max_number_operands
import itertools
import lib_para
import IfElse_Arrays
import Template
from Template import Max_no_previous_addreeses
def Add_Into_Structure_Array_If(results, inputs, operator_num, number_of_operands, 
                             number_of_results, delay_cycles):
    
    # Update how many if we have now
    #lib_para.If_counter = lib_para.If_counter + 1
    
    final_previous_addresses = list(itertools.repeat(-1,Template.Max_no_previous_addreeses))
    number_of_previous_addresses = list(itertools.repeat(1, Max_number_operands))
    
    
    # Find the previous addresses of the inputs
    lib_para.Address_counter_if = lib_para.Address_counter_if + 1
    
    # Defualt address should be at -1 (input)   
    previous_addresses = list(itertools.repeat(-1, Max_no_previous_addreeses))
    
    position = lib_para.Address_counter
    # Find the current position of the structure array
    position_inIf =  lib_para.Address_counter_if
    
    # When the equation is the first (inputs are from the circuit inputs)
    if(position_inIf == 0):
        # -1 means this should be the input
        previous_addresses = list(itertools.repeat(-1, Max_no_previous_addreeses))
        
    
    
        
        

    # When it is the second or later equation, in this case, all the previous 
    # equation record structures should be scanned and compared
    else:
        for i in range(0, position_inIf):
            num_of_pre_result = lib_para.Eq_record_if_1[i]['number_of_results']
            
            # Try to find all the operands previous addresses
            for j in range(0, number_of_operands):
                # Find the previous equation results elements and compare with
                # the operand's name one by one
                for k in range(0, num_of_pre_result):
                    if(lib_para.Eq_record_if_1[i]['result_name_array'][k] == inputs[j]): 
                        previous_addresses[j] = i 
                        # + position to get the position in the whole array
                        # without + position, it will be position only in the if
                        # structure array


    
    for i in range(0, number_of_results):
        IfElse_Arrays.if_results_names.append(results[i])
    
    
    # Generate the function array
    New_update_array = np.array([(inputs, number_of_operands, operator_num, 
                                results, number_of_results, 
                                previous_addresses, number_of_previous_addresses, delay_cycles)], 
                          dtype=dt)
    if(lib_para.Address_counter_if == 0):
        lib_para.Eq_record_if_1 = New_update_array
        
    else:
        lib_para.Eq_record_if_1 = np.concatenate((lib_para.Eq_record_if_1, 
                                                 New_update_array)
                                                 , axis=0)
    
    
    
    
    
    


