# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 10:24:49 2024

@author: elx22yz
"""

''' 14/06/2024
    Version 0.0.1
    This is the function to update the user design function into the library
    for future use.
    
'''
import lib_para
import update_function_number

def Updater(module_name, delay):
    for ii in range(0, len(lib_para.output_names)):
        module_name = module_name + "_" + lib_para.output_names[ii]
        function_file_name = module_name + "_Gen.py"
        function_file_name_if = module_name + "_IF_Gen.py"
        function_file_name_else = module_name + "_Else_Gen.py"
        
        no_input = len(lib_para.input_names)
        no_output = len(lib_para.output_names)
        
        
        # Update the function number 
        function_number = update_function_number.update_function_number
        f = open("update_function_number.py", "w")  
        f.write("update_function_number = " + str(function_number+1))
        f.close()
        
        import New_function_names
        temp_New_function_names = New_function_names.New_function_names
        f = open("New_function_names.py", "w")  
        f.write("\nNew_function_names = [")
        for i in range(0, len(temp_New_function_names)): 
            f.write("'"+temp_New_function_names[i] + "',")
        
        f.write("'" + module_name + "']")
        
        f.close()
        
        # Print the general function
        f = open(function_file_name, "w")    
        f.write("from Add_Into_Structure_Array import Add_Into_Structure_Array\n" +
        "import itertools\n" +
        "from Template import Max_number_operands\n" +     
        "from Template import Max_number_results\n" +
        "def " + module_name + "_V(") 
        
        for i in range (0, no_output):
            f.write("output_" + str(i) + ",")
            
        for i in range (0, no_input):
            if( i == (no_input -1)):
               f.write("input_" + str(i))
               
            else:
                f.write("input_" + str(i) + ",")
            
        f.write("):\n")
        
        f.write("\tresults = list(itertools.repeat('0', Max_number_results))\n")
        f.write("\tinputs = list(itertools.repeat('0', Max_number_results))\n")
        
        for i in range (0, no_output):
            f.write("\tresults[" + str(i) + "] = output_" + str(i) + "\n")
        
        for i in range (0, no_input):
            f.write("\tinputs[" + str(i) + "] = input_" + str(i) + "\n")
        
    
        
        f.write("\n\toperator_num =" + str(function_number) )
        f.write("\n\tnumber_of_operands = " + str(no_input))
        f.write("\n\tnumber_of_results =" + str(no_output))
        
        f.write("\n\tAdd_Into_Structure_Array(results, inputs, operator_num, number_of_operands, " 
                + "number_of_results, " + str(delay[ii]) + ")")
     
        
        f.close()
        
        
        
        
        
        
        
        # Print the if version
        f = open(function_file_name_if, "w")    
        f.write("from Add_Into_Structure_Array_If import Add_Into_Structure_Array_If\n" +
        "import itertools\n" +
        "from Template import Max_number_operands\n" +     
        "from Template import Max_number_results\n" +
        "def " + module_name + "_IF_V(") 
        
        for i in range (0, no_output):
            f.write("output_" + str(i) + ",")
            
        for i in range (0, no_input):
            if( i == (no_input -1)):
               f.write("input_" + str(i))
               
            else:
                f.write("input_" + str(i) + ",")
            
        f.write("):\n")
        
        f.write("\tresults = list(itertools.repeat('0', Max_number_results))\n")
        f.write("\tinputs = list(itertools.repeat('0', Max_number_results))\n")
        
        for i in range (0, no_output):
            f.write("\tresults[" + str(i) + "] = output_" + str(i) + "\n")
        
        for i in range (0, no_input):
            f.write("\tinputs[" + str(i) + "] = input_" + str(i) + "\n")
        
    
        
        f.write("\n\toperator_num =" + str(function_number) )
        f.write("\n\tnumber_of_operands = " + str(no_input))
        f.write("\n\tnumber_of_results =" + str(no_output))
        
        f.write("\n\tAdd_Into_Structure_Array_If(results, inputs, operator_num, number_of_operands, " 
                + "number_of_results, " + str(delay[ii]) + ")")
     
        
        f.close()
        
        
        
        
        
        
        
        
        
        
        
        
        # Print the Else version
        f = open(function_file_name_else, "w")    
        f.write("from Add_Into_Structure_Array_Else import Add_Into_Structure_Array_Else\n" +
        "import itertools\n" +
        "from Template import Max_number_operands\n" +     
        "from Template import Max_number_results\n" +
        "def " + module_name + "_Else_V(") 
        
        for i in range (0, no_output):
            f.write("output_" + str(i) + ",")
            
        for i in range (0, no_input):
            if( i == (no_input -1)):
               f.write("input_" + str(i))
               
            else:
                f.write("input_" + str(i) + ",")
            
        f.write("):\n")
        
        f.write("\tresults = list(itertools.repeat('0', Max_number_results))\n")
        f.write("\tinputs = list(itertools.repeat('0', Max_number_results))\n")
        
        for i in range (0, no_output):
            f.write("\tresults[" + str(i) + "] = output_" + str(i) + "\n")
        
        for i in range (0, no_input):
            f.write("\tinputs[" + str(i) + "] = input_" + str(i) + "\n")
        
    
        
        f.write("\n\toperator_num =" + str(function_number) )
        f.write("\n\tnumber_of_operands = " + str(no_input))
        f.write("\n\tnumber_of_results =" + str(no_output))
        
        f.write("\n\tAdd_Into_Structure_Array_Else(results, inputs, operator_num, number_of_operands, " 
                + "number_of_results, " + str(delay[ii]) + ")")
     
        
        f.close()
    
    
    
    
    
    