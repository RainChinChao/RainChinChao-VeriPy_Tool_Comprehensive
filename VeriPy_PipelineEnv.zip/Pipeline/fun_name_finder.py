# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 11:43:18 2024

@author: elx22yz
"""
''' 14/06/2024
    Version 0.1.0 This function is for finding the new updated function name 
    to do the Verilog Gen
    
'''
import New_function_names


def fun_name_finder(operator_no):
    return New_function_names.New_function_names[operator_no-1000]