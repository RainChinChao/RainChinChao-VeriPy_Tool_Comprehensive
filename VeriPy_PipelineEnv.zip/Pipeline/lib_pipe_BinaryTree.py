# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 14:24:19 2024

@author: elx22yz
"""

''' 05/06/2024
    Version 0.0.1
    This is the to store the level information which can derive the pipeline 
    binary tree in the future
    
'''





Max_no_Level = 10000



Level_info_temp = []

Level_info_array = [Level_info_temp.copy() for _ in range(Max_no_Level)]

level_count = 0





if_count = 0
add_count = 0
substract_count = 0
mul_count = 0
div_count = 0
power_count = 0
log_count = 0
sqrt_count = 0
sincostan_count = 0
value_count = 0









level_valid = []
level_start = []


Level_valid_array = [level_valid.copy() for _ in range(Max_no_Level)]
Level_start_array = [level_start.copy() for _ in range(Max_no_Level)]
