# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 10:19:54 2024

@author: elx22yz
"""

"""
25/06/2024 

This function is to establish the real binary tree from our form Eq_Record.
Limits: 1. No if/else statement
        2. No non-1 delay subfunction print

"""

import lib_para
import numpy as np

previous_addresses_array= []


tree_0 = []
tree_1 = []
tree_2 = []
tree_3 = []
tree_4 = []
tree_5 = []
tree_6 = []
tree_7 = []
tree_8 = []
tree_9 = []
tree_10 = []
tree_11 = []
tree_12 = []
tree_13 = []
tree_14 = []
tree_15 = []
tree_16 = []
tree_17 = []
tree_18 = []
tree_19 = []
    
recall_level = -1



# This function is to find the result equation address
def address_finder(result_name):
    counter_all = lib_para.Address_counter
    binary_tree_main = lib_para.Eq_record
    
    for i in range(0, counter_all + 1):
        results = binary_tree_main[i]['result_name_array']
        no_results = binary_tree_main[i]['number_of_results']        
        
        for j in range(0, no_results):
            if(results[j] == result_name):
                return i
        if(j == counter_all + 1):
            print("Cannot find the result name!")



import itertools
Initial_inputs_names = list(itertools.repeat('0', 100))

temp_tree = []
#temp_tree_array[10000] = [-2]
level_no_max = -1

temp_array_tree = []

# This function is to build the tree according to the result function
def recall_fun(result_address):   
    global recall_level 
    recall_level = recall_level + 1
    global temp_tree
    global temp_array_tree
    global previous_addresses_array
    
    
    # record the worst case length
    global level_no_max
    if(recall_level > level_no_max):
        level_no_max = recall_level
    
    
    if(recall_level == 0):
        
        #print(result_address)
        temp_tree = previous_addresses_array[result_address]
        
        temp_array_tree = [np.array([result_address]) , previous_addresses_array[result_address]]
        
        #recall_level = recall_level + 1
        
        #temp_array_tree.append(previous_addresses_array[result_address])
        
        
        #print("Recall Level: " + str(recall_level))
        #print("Tree Level: " + str(len(temp_array_tree)))
        
        #print("Add elements:")
        #print(previous_addresses_array[result_address])
        #print("Tree after add:")
        #print(temp_array_tree)   
    else:
        
        temp_tree = [temp_tree, previous_addresses_array[result_address]]
        #temp_tree = np.array(temp_tree, dtype=object)
        #temp_tree.append(previous_addresses_array[result_address])
        
        
        #print("Recall Level: " + str(recall_level))
        #print("Tree Level: " + str(len(temp_array_tree)))
        
        #print("Add elements:")
        #print(previous_addresses_array[result_address])
        
        
        
        
        # Use Append to have a new level
        if(recall_level + 2 > len(temp_array_tree) ):
            
            for i in range (0, len(previous_addresses_array[result_address])):
                if(i == 0):
                    temp_array_tree.append(np.array([previous_addresses_array[result_address][i]]))
                else:
                    temp_array_tree[recall_level + 1] = np.append(temp_array_tree[recall_level + 1], 
                                                              previous_addresses_array[result_address][i])
                    
                #print(temp_array_tree)
        # Add element into existing level
        else:
            for i in range (0, len(previous_addresses_array[result_address])):
                
                #print(previous_addresses_array[result_address][i])
                #print("recall_level = " + str(recall_level))
                #print(temp_array_tree[recall_level])
                #print(temp_array_tree)
                #print("Length of temp_array_tree = " + str(len(temp_array_tree)))
                #print("Current Small element = " + str(previous_addresses_array[result_address][i]))
                temp_array_tree[recall_level + 1] = np.append(temp_array_tree[recall_level + 1], 
                                                          previous_addresses_array[result_address][i])
                
                #print("Tree After Small element = ")
                #print( temp_array_tree)
        
        #print("Tree after add:")
        #print(temp_array_tree)
    # To search backwards the tree through previous addresses
    for i in range(0, len(previous_addresses_array[result_address])):
        if(previous_addresses_array[result_address][i]>=0):
            #print(previous_addresses_array[result_address][i])
            recall_fun(previous_addresses_array[result_address][i])
     

    recall_level = recall_level - 1
    # if(recall_level == -1):
    #     #print(temp_tree)
    #     #print(level_no_max+2)
    #     ff=1

    # #return temp_array_tree








add_count = 0
substract_count = 0
mul_count = 0
div_count = 0
power_count = 0
log_count = 0
sqrt_count = 0
sincostan_count = 0
value_count = 0


start_signals = []
valid_signals = []





# Print each equation respectively
def print_eq(print_file_name, address, current_input_names, input_name_delay, current_level):
    
    
    global start_signals
    global valid_signals
    
    
    global add_count
    global substract_count
    global mul_count 
    global div_count 
    global power_count
    global log_count 
    global sqrt_count
    global sincostan_count
    global value_count
    
    print(input_name_delay)
    current_equation = lib_para.Eq_record[address]
    
    operands_pr = current_equation['operand_name_array']
    no_operands_pr = current_equation['number_of_operands']        
    operator_pr = current_equation['operator'] 
    results_pr = current_equation['result_name_array']
    no_results_pr = current_equation['number_of_results']
    #previous_addresses = current_equation['previous_address']
    #no_previous_adresses = current_equation['no_of_previous_address']
    #delay_cycles_pr = current_equation['delay cycles']

    match operator_pr:
        
        # +
        case 1:
            name_comp = "addition_HDL_Level" + str(current_level) + "_"+ str(add_count)
            
            # # Generate control line for the main function
            # start_line_name = "start_" + name_comp
            # valid_line_name = "valid_" + name_comp 
            # busy_line_name = "busy_" + name_comp
            
            # # Store the valid and start signals in the array for the future connection
            # start_signals[current_level] = np.append(start_signals[current_level], start_line_name)
            # valid_signals[current_level] = np.append(valid_signals[current_level], valid_line_name)
            
            
            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            # print(operands_pr)
            # print(operands_pr[0])
            #print(current_input_names[0])
            # When a delay is needed for the input signal 0
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # start_line_name_delay = "start_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[0]
                    # valid_line_name_delay = "valid_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[0]
                    # busy_line_name_delay = "busy_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[0]
                    
                    # f.write("\twire "+ start_line_name_delay +";\n" + 
                    #         "\twire "+ valid_line_name_delay +";\n" +
                    #         "\twire "+ busy_line_name_delay +";\n"        
                    #              )
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                        # # Add control signals into the array
                        # start_signals[current_level + input_name_delay[0]] = np.append(start_signals[current_level + input_name_delay[0]], start_line_name_delay)
                        # valid_signals[current_level + input_name_delay[0]] = np.append(valid_signals[current_level + input_name_delay[0]], valid_line_name_delay)
                        
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                            
                            # # Add control signals into the array
                            # start_signals[current_level + input_name_delay[0]] = np.append(start_signals[current_level + input_name_delay[0]], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[0]] = np.append(valid_signals[current_level + input_name_delay[0]], valid_line_name_delay)
                            
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            # # Add control signals into the array
                            # start_signals[current_level + input_name_delay[0] - i - 1] = np.append(start_signals[current_level + input_name_delay[0] - i], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[0] - i - 1] = np.append(valid_signals[current_level + input_name_delay[0] - i], valid_line_name_delay)
                            
                            
                            
                            
                            
                            
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            # start_signals[current_level + input_name_delay[0] - i - 1] = np.append(start_signals[current_level + input_name_delay[0] - i], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[0] - i - 1] = np.append(valid_signals[current_level + input_name_delay[0] - i], valid_line_name_delay)
                            
                            
                   
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                    # start_line_name_delay = "start_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[1]
                    # valid_line_name_delay = "valid_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[1]
                    # busy_line_name_delay = "busy_delay_Level_" + str(current_level) + "_"  + str(i) + "_" + current_input_names[1]
                    
                    # f.write("\twire "+ start_line_name_delay +";\n" + 
                    #         "\twire "+ valid_line_name_delay +";\n" +
                    #         "\twire "+ busy_line_name_delay +";\n"        
                    #              )
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    #     # Add control signals into the array
                    #     start_signals[current_level + input_name_delay[0]] = np.append(start_signals[current_level + input_name_delay[0]], start_line_name_delay)
                    #     valid_signals[current_level + input_name_delay[0]] = np.append(valid_signals[current_level + input_name_delay[0]], valid_line_name_delay)
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                            # # Add control signals into the array
                            # start_signals[current_level + input_name_delay[1]] = np.append(start_signals[current_level + input_name_delay[1]], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[1]] = np.append(valid_signals[current_level + input_name_delay[1]], valid_line_name_delay)
                            
                            
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                            # # Add control signals into the array
                            # start_signals[current_level + input_name_delay[1] - i - 1] = np.append(start_signals[current_level + input_name_delay[1] - i], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[1] - i - 1] = np.append(valid_signals[current_level + input_name_delay[1] - i], valid_line_name_delay)
                            
                            
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            # start_signals[current_level + input_name_delay[1] - i - 1] = np.append(start_signals[current_level + input_name_delay[1] - i], start_line_name_delay)
                            # valid_signals[current_level + input_name_delay[1] - i - 1] = np.append(valid_signals[current_level + input_name_delay[1] - i], valid_line_name_delay)
                            
            
            
            
            
            
            
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " + " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            
            f.write("\taddition_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, reset);\n\n\n\n\n")                        
            f.close()
            
        
            
            add_count = add_count + 1
            
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        #-    
        case 2:
            name_comp = "subtraction_HDL_Level" + str(current_level) + "_"+ str(substract_count)
            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                   
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                           
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                          
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " - " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            
            f.write("\tSubtraction_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, reset);\n\n\n\n\n")                        
            f.close()
            
        
            
            substract_count = substract_count + 1
           
            
           
            
           
            
           
            
           
            
           
            
        # *    
        case 3:
            
            name_comp = "mul_HDL_Level" + str(current_level) + "_"+ str(mul_count)

            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                   
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                           
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                          
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " * " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            
            f.write("\tmul_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, reset);\n\n\n\n\n")                        
            f.close()
            
        
            
            mul_count = mul_count + 1
        
            
        
        
        
        
        
        # /    
        case 4:
            name_comp = "division_HDL_Level" + str(current_level) + "_"+ str(div_count)

            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                   
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                           
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                          
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " / " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            
            f.write("\tDivision_always "+ name_comp +"(" + input_name_0 
                    + ", "  + input_name_1 + ", " + result_name_ + 
                    ", clk, reset);\n\n\n\n\n")                        
            f.close()
            
        
            
            div_count = div_count + 1
            
            
            
            
            
            
            
        # Power    
        case 5:
            name_comp = "power_HDL_Level" + str(current_level) + "_"+ str(power_count)

            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                   
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                           
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                          
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = "
                    + input_name_0 + " ^ " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            

            f.write("\tPower_PN "+ name_comp +"( clk, " + input_name_0 
                            + ", ("  + input_name_1 + ">>16), " + result_name_ + 
                            ",  reset);\n"
                                 )                       
            f.close()
            
        
            
            power_count = power_count + 1
         
            
         
            
         
            
         
            
         
        # Log    
        case 6:
            name_comp = "log_HDL_Level" + str(current_level) + "_"+ str(log_count)

            
            input_name_0 = current_input_names[0]
            input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
                    
                    
            # When a delay is needed for the input signal 1       
            if(operands_pr[1] != current_input_names[1]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[1] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[1]):
                    
                   
                    # When there is only 1 delay needed
                    if(input_name_delay[1] == 1):
                        input_name_0_delay = operands_pr[1]
                        result_name_delay = current_input_names[1]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[1] 
                                + " (clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                        
                        
                    else:    
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[1]
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                           
                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[1] - 1):
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[1]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " (clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                          
                            
                        else:
                            input_name_0_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[1] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[1] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = log base("
                    + input_name_0 + ") " +  input_name_1 + "\n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            

            f.write("\tlog_inout "+ name_comp + "( clk, reset, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ");\n"
                                 )                      
            f.close()
            
        
            
            log_count = log_count + 1
        
            
        
        
        
        
        
        
        
        # SQRT    
        case 7:
            name_comp = "sqrt_HDL_Level" + str(current_level) + "_"+ str(sqrt_count)

            
            input_name_0 = current_input_names[0]
            #input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    

                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = sqrt("
                    + input_name_0 + ") \n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            

            f.write("\tsqrt "+ name_comp + " ( clk, " + input_name_0 +
                            ", reset, " + result_name_ + ");\n"
                                 )                     
            f.close()
            
        
            
            sqrt_count = sqrt_count + 1
            
        
        
        
        
        
        
        
        
        
        
        
        
        # Sin/Cos/Tan    
        case 8:
            name_comp = "sincostan_HDL_Level" + str(current_level) + "_"+ str(sincostan_count)

            
            input_name_0 = current_input_names[0]

            result_name_0 = results_pr[0]
            result_name_1 = results_pr[1]
            result_name_2 = results_pr[2]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    
           
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_0 + " = sin(" + input_name_0 + 
                    "\n\t//" + result_name_1 + " = cos (" +  input_name_0 + ")"
                    + "\n\t//" + result_name_2 + " = tan (" +  input_name_0 + ")\n")
            
            
            
            f.write("\twire [31:0]" + result_name_0 +";\n")
            f.write("\twire [31:0]" + result_name_1 +";\n")
            f.write("\twire [31:0]" + result_name_2 +";\n")
            
            f.write("\ttan_inout "+ name_comp + " ( clk, " + input_name_0 + 
                            ", " + result_name_0 + ", " + result_name_1 + ", " 
                            + result_name_2 + ", reset);\n"
                                 )                      
            f.close()
            
        
            
            sincostan_count = sincostan_count + 1
            
        
        
        
        
        
        
        
        
        
        # Value   
        case 9:
            name_comp = "Value_HDL_Level" + str(current_level) + "_"+ str(value_count)

            
            input_name_0 = current_input_names[0]
            #input_name_1 = current_input_names[1]
            result_name_ = results_pr[0]
            
            
            if(operands_pr[0] != current_input_names[0]):
                # Comments
                f = open(print_file_name, "a")
                f.write("\t//Proceed delay with " + current_input_names[0] + "\n")
                # Need to print all the delay functions
                for i in range (0, input_name_delay[0]):
                    
                    # When there is only 1 delay needed
                    if(input_name_delay[0] == 1):
                        input_name_0_delay = operands_pr[0]
                        result_name_delay = current_input_names[0]
                        
                        f.write("\twire [31:0]" + result_name_delay + ";\n")
                        
                        f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                + "_"  + str(i) + "_" + current_input_names[0] 
                                + " ( clk, reset, " + input_name_0_delay + 
                                ", " + result_name_delay + ");\n")
                                                                      
                    else: 
                        # For the first appearance, print input is the original input
                        if(i == 0):
                            
                            input_name_0_delay = operands_pr[0]
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                            
                                                        
                        # For the last appearance, print input is the current input
                        elif(i == input_name_delay[0] - 1):
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = current_input_names[0]
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                            
                        else:
                            input_name_0_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i - 1)
                            result_name_delay = operands_pr[0] + "_delay_Level_" + str(current_level) + "_delay_"  + str(i)
                            f.write("\twire [31:0]" + result_name_delay + ";\n")
                            
                            f.write("\tdelay "+ "delay_Level_" + str(current_level) 
                                    + "_"  + str(i) + "_" + current_input_names[0] 
                                    + " ( clk, reset, " + input_name_0_delay + 
                                    ", " + result_name_delay + ");\n")
                           
                    

                        
            
            
            f = open(print_file_name, "a")
            
            # Comments
            f.write("\t//Proceed with " + result_name_ + " = delay("
                    + input_name_0 + ") \n"
                         )
            
            
            
            f.write("\twire [31:0]" + result_name_ +";\n"   
                         )
            

            f.write("\tdelay "+ name_comp + " ( clk, reset, " + input_name_0 + 
                            ", " + result_name_ + ");\n"
                                 )                    
            f.close()
            
        
            
            value_count = value_count + 1
            
            
        # # Other cases  
        # case _:
            
































def Veri_Gen(file_name, temp_array_tree_s):
    
    
    #counter_all = lib_para.Address_counter
    binary_tree_main = lib_para.Eq_record    
    # Create a list of empty numpy arrays with the array size + 1, last level for 
    # input names
    input_name_tree = [np.array([]) for _ in range(len(temp_array_tree_s))]
    #print(len(temp_array_tree_s))
    
    
    global start_signals
    global valid_signals
    
    start_signals = [np.array([]) for _ in range(len(temp_array_tree_s))]
    valid_signals = [np.array([]) for _ in range(len(temp_array_tree_s))]
    
    # Put input names of the whole module into the first level
    for j in range (0, len(lib_para.input_names)):
        input_name_tree[len(temp_array_tree_s) - 1] =np.append(input_name_tree[len(temp_array_tree_s) - 1] ,lib_para.input_names[j])
    
    
    for j in range(len(temp_array_tree_s) - 1, -1, -1):
        #print(temp_array_tree_s[j])
        
        # in small array to find the eq number
        for k in range(0, len(temp_array_tree_s[j])):
            current_eq_number = temp_array_tree_s[j][k]
            no_operands_current = binary_tree_main[current_eq_number]['number_of_operands']    
            operands_current = binary_tree_main[current_eq_number]['operand_name_array'][0 : no_operands_current]
            #print(operands_current) 
            for l in range(0, len(operands_current)):
                input_name_tree[j] =np.append(input_name_tree[j] ,operands_current[l])
            
        #end for k
    #end for j
    
    #print(input_name_tree) 
    
    # Delete iterative element in every array
    for i in range(0, len(input_name_tree)):
        arr = input_name_tree[i]

        # Get unique elements while preserving the order of their first occurrence
        _, idx = np.unique(arr, return_index=True)
        unique_arr = arr[np.sort(idx)]
        
        #print(unique_arr)
        input_name_tree[i] = unique_arr
        #print(input_name_tree[i])
    print(input_name_tree)

    

    # Till now, the array of "input_name_tree" consists the non-iterative inputs
    # names in each level. In the highest level, it contains the whole module 
    # input names.






    print_file_name = file_name + ".v"
    
    f = open(print_file_name, "w")
    
    
    # module name, input signals
    f.write("module " + str(file_name) + "(")
    
    for i in range(0, len(lib_para.input_names)):
        f.write("input [31:0]" + lib_para.input_names[i] + ", ")
    
    for i in range(0, len(lib_para.output_names)):
        f.write("output [31:0]" + lib_para.output_names[i] + ", ")

    f.write("input clk, input reset, input start, output valid, output busy);\n")
    
    
    f.close()


    # main part of the algorithm
    
    # Scan from the highest level (input side) to lowest level (output side)
    for i in range(len(temp_array_tree_s) - 1, -1, -1):
        
        # Proceed with equation by equation in the same level
        for j in range(0, len(temp_array_tree_s[i])):
            no_operands_current = binary_tree_main[temp_array_tree_s[i][j]]['number_of_operands']    
            current_input_names_ = binary_tree_main[temp_array_tree_s[i][j]]['operand_name_array'][0 : no_operands_current]
            updated_input_names = []
            
            for k in range (0, len(current_input_names_)):
                updated_input_names.append(current_input_names_[k])
                
                
            #end for k
            
            #updated_input_names = current_input_names
            #print(current_input_names)
            
            # Update input names if it shows in a higher level
            # +1 when appear in a previous level once
            input_name_delay = []
            # Select one of the input names in the current equation
            for k in range (0, len(current_input_names_)):
                appearance_times = 0
                biggest_delay_current = 0
                current_input_name_ele = current_input_names_[k]
                #print(current_input_name_ele)
                # Select the input names in the higher level
                for l in range(len(input_name_tree) - 1, i, -1):
                    current_level_names_array = input_name_tree[l]
                    
                    # Select the element in the previous level of names
                    for m in range (0, len(current_level_names_array)):   
                        
                        if(current_input_name_ele.isnumeric()):
                            break
                        
                        if(current_input_name_ele == current_level_names_array[m]):
                            appearance_times = appearance_times + 1
                            # Update the largest delay
                            if(biggest_delay_current < (l - i)):
                                biggest_delay_current = l - i
                            break
                    
                    #end for m
                #end for l
                if(appearance_times != 0):
                    updated_input_names[k] = current_input_name_ele + "_new_gen_" + str(appearance_times) 
                input_name_delay.append(biggest_delay_current)
            print(current_input_names_)
            print(updated_input_names)
            
            
            #end for k
            
            # Print current equation in the .v file using the print_eq function
            # i is the current level of the equation
            print_eq(print_file_name, temp_array_tree_s[i][j], updated_input_names, input_name_delay, i)
            
            
        #end for j
    #end for i


    f = open(print_file_name, "a")
    f.write("endmodule\n")
    f.close()






def real_binary_tree_est(file_name):
    
    
    
    global tree_0
    global tree_1
    global tree_2
    global tree_3
    global tree_4 
    global tree_5
    global tree_6 
    global tree_7 
    global tree_8 
    global tree_9 
    global tree_10
    global tree_11 
    global tree_12 
    global tree_13 
    global tree_14 
    global tree_15 
    global tree_16 
    global tree_17 
    global tree_18 
    global tree_19 
    
    
    
    

    
    counter_all = lib_para.Address_counter
    binary_tree_main = lib_para.Eq_record
    
    #previous_addresses_array= []
    
    
    # Find pure previous addresses
    for i in range (0, counter_all + 1):
        
        
        no_operands = binary_tree_main[i]['number_of_operands']      
        previous_addresses = binary_tree_main[i]['previous_address']
        no_previous_adresses = binary_tree_main[i]['no_of_previous_address']
        
        no_address = 0
        for j in range (0, no_operands):
            no_address = no_address + no_previous_adresses[j]
            
        previous_addresses_array.append( previous_addresses[0:no_address] )
            
        #end for j
        
        
    # end for i

    #print(len(lib_para.output_names))
    # Do the recall function to build the tree
    for i in range(0, len(lib_para.output_names)):
        
        #print(lib_para.output_names[i])
        result_address = address_finder(lib_para.output_names[i])
        global temp_array_tree
        temp_array_tree = []
       
        recall_fun(result_address)
        #print(temp_array_tree)
        
        
        
        # Store the temp_array_tree into other arrays
        # Maximum number of outputs is 20
        match i:
        
            case 0:
                tree_0 = temp_array_tree
            case 1:
                tree_1 = temp_array_tree
            case 2:
                tree_2 = temp_array_tree
            case 3:
                tree_3 = temp_array_tree
            case 4:
                tree_4 = temp_array_tree
            case 5:
                tree_5 = temp_array_tree
            case 6:
                tree_6 = temp_array_tree
            case 7:
                tree_7 = temp_array_tree
            case 8:
                tree_8 = temp_array_tree
            case 9:
                tree_9 = temp_array_tree
            case 10:
                tree_10 = temp_array_tree
            case 11:
                tree_11 = temp_array_tree
            case 12:
                tree_12 = temp_array_tree
            case 13:
                tree_13 = temp_array_tree
            case 14:
                tree_14 = temp_array_tree
            case 15:
                tree_15 = temp_array_tree
            case 16:
                tree_16 = temp_array_tree
            case 17:
                tree_17 = temp_array_tree
            case 18:
                tree_18 = temp_array_tree
            case 19:
                tree_19 = temp_array_tree
        
        
        
        # Now simplify the tree, eliminate -1 and iterative eq no.
        
        # Define simplified version of tree
        # last level of "all -1" will not be included 
        temp_array_tree_s = temp_array_tree[0:len(temp_array_tree)-1]
        
        #print(temp_array_tree_s)
        
        
        # This step will delete all the -1 elements in the array
        for j in range(len(temp_array_tree_s)):
            temp_array_tree_s[j] = temp_array_tree_s[j][temp_array_tree_s[j] != -1]

     
        #print(temp_array_tree_s)
        
        
        
        # This step will delete all the iterative elements and keep the 
        # only one at the highest level of the array
        
        # Set to keep track of seen elements
        seen = set()

        # Traverse the list in reverse order
        for j in range(len(temp_array_tree_s)-1, -1, -1):
            unique_elements = []
            for element in reversed(temp_array_tree_s[j]):  # Reverse the sub-array iteration to keep the last occurrence
                if element not in seen:
                    unique_elements.append(element)
                    seen.add(element)
            #end for element
            temp_array_tree_s[j] = np.array(unique_elements[::-1])  # Reverse again to maintain original order within the sub-array
        #end for j
        print(temp_array_tree_s)
        
        
        
        # Get the input names in different levels
        # Same input names in the same level can share the same name
        # Same input names in different levels should have different names
      
        file_name_current = file_name + "_" + lib_para.output_names[i]
        
        Veri_Gen(file_name_current, temp_array_tree_s)
        
        
        
        
        
        
    
    
    #end for i
    

    



    

    
    
    
    
    
    
    
    
    
    