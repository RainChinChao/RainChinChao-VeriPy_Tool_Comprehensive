# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 10:36:49 2024

@author: elx22yz
"""
''' 03/06/2024
    Version 0.0.1
    This is the function to tace back all the branches for a pipeline design 
    generation
    
'''


import numpy as np
from Template import dt
import IfElse_Arrays
import lib_para
from Verilog_IF_Else_Gen import if_module_gen
from Verilog_IF_Else_Gen import else_module_gen
import Verilog_IF_Else_Gen
import Verilog_IF_Else_Inout_Gen
from array_print_top import array_print_top
from input_output_print_top import input_output_print_top
from array_content_print_top import array_content_print_top

import lib_in_out_names 
file_name = 0

import lib_para
import Verilog_Generation
import lib_in_out_names



template_branch = ['0', -1]

branch_array = [template_branch]




# This function is to generate all the branches according to the binary tree
# s for current address, final for boolean of final result or not
def recall_function(s, result_name, final, file_name):
    binary_tree_main_r = lib_para.Eq_record
    

    global branches_tree
    #top_generation_function_pipe(file_name)

    
    # When the final result name is under processing
    if(final == 1):
        branches_tree[1] = [result_name, s]
        
        operands_r = binary_tree_main_r[s]['operand_name_array']
        no_operands_r = binary_tree_main_r[s]['number_of_operands']        
        operator_r = binary_tree_main_r[s]['operator']
        previous_addresses_r = binary_tree_main_r[s]['previous_address']
        no_previous_adresses_r = binary_tree_main_r[s]['no_of_previous_address']
        
        
        # When the current equation is in an If/Else statement
        if(operator_r == 0):
            sdffd = 0
            
            
        # When the current equation is not in an If/Else statement
        else:
            
            
            current_base_no_address = 0
            # Deal with operand one by one
            for i in range(0, no_operands_r):
                
                if(i == 0):
                    current_base_no_address = 0
                
                
                
                # If there is only 1 previous address of this operand
                if(no_previous_adresses_r[i] == 1):
                    
                    
                    recall_function(current_base_no_address +1
                                    , operands_r[i], 0, file_name)
                
                
                
                
                
                    
                
                
                # If there are more than 1 previous addresses of this operand
                else:
                    
                    # Do the previous address one by one
                    for j in range (current_base_no_address, current_base_no_address + no_previous_adresses_r[i]):
                        recall_function(j, operands_r[i], 0, file_name)
            
        
                current_base_no_address = current_base_no_address + no_previous_adresses_r[i]
        
        
        
    # When now is previous result name under processing    
    else:
        operands_r = binary_tree_main_r[s]['operand_name_array']
        no_operands_r = binary_tree_main_r[s]['number_of_operands']        
        operator_r = binary_tree_main_r[s]['operator']
        previous_addresses_r = binary_tree_main_r[s]['previous_address']
        no_previous_adresses_r = binary_tree_main_r[s]['no_of_previous_address']











def branch_gen(a, file_name):
    
    
    
    binary_tree_main = lib_para.Eq_record
    counter_all = lib_para.Address_counter
    no_if = lib_para.If_counter
    else_count = lib_para.Else_counter
    storage_delay_if = IfElse_Arrays.if_delay
    storage_delay_else = IfElse_Arrays.else_delay
    storage_binary_tree_if = IfElse_Arrays.if_array
    storage_binary_tree_else = IfElse_Arrays.else_array
    if_addresses = IfElse_Arrays.start_address_if



    
    # Find branches in different result
    for i in range (0, len(lib_para.output_names)):
        current_output = lib_para.output_names[i]
        
        # Find the last equation of current result
        counter_all = lib_para.Address_counter
        for j in range (counter_all + 1, 0, -1):
            operands = binary_tree_main[j]['operand_name_array']
            no_operands = binary_tree_main[j]['number_of_operands']        
            operator = binary_tree_main[j]['operator'] 
            results_array = binary_tree_main[j]['result_name_array']
            no_results = binary_tree_main[j]['number_of_results']
            previous_addresses = binary_tree_main[j]['previous_address']
            no_previous_adresses = binary_tree_main[j]['no_of_previous_address']
            delay_cycles = binary_tree_main[j]['delay cycles']
            # Find out the current result content
            
            
            for k in range (0, no_results):
                result = results_array[k]
            
                if(result == current_output):
                    address_current_output = j
                    
                    
                    
                    break
                recall_function(j, result, 1, file_name)
            














