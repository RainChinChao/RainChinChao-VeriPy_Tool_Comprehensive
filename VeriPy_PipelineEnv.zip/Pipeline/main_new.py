# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 14:33:47 2024

@author: elx22yz
"""
''' 18/03/2024
    Version 0.0.1
    This is the function the main function that calls all kinds of generation 
    functions like Addition_V, Multi_V, etc.
'''

import numpy as np
from Template import dt
#from Addition_Gen import Addition_V
from SinCosTan_Gen import SinCosTan_V
from Addition_Gen import Addition_V
from Logarithm_Gen import Logarithm_V
from Division_Gen import Division_V
from Multiplication_Gen import Multiplication_V
from Power_Gen import Power_V
from Sqrt_Gen import Sqrt_V
from Subtraction_Gen import Subtraction_V
from Value_Gen import Value_V
from Addition_IF_Gen import Addition_IF_V
from Addition_Else_Gen import Addition_Else_V
from If_Gen import If_V
from Else_Gen import Else_V
import lib_para
from End_IfElse_Gen import End_IfElse_V
from Addition_Index_Gen import Addition_Index_V
from SinCosTan_Index_Gen import SinCosTan_Index_V
from Sqrt_Index_Gen import Sqrt_Index_V
import IfElse_Arrays
lib_para.Address_counter = -1
# Initialize Address_counter = 0


'''
Addition_V1('c', 'a', 'b')
Addition_V1('f', 'a', 'c')
Addition_V1('g', 'a', 'f')
Addition_V1('h', 'f', 'c')
Addition_V1('x', 'y', 'z')
'''


Addition_V('c', 'a', 'b') #0
SinCosTan_V('x', 'y', 'z', 'c') #1
Addition_V('d', 'x', 'a') #2

Addition_V('e', 'd', 'y') #3
Addition_V('f', 'e', 'z') #4
Addition_V('h', 'f', 'g') #5


If_V("f", 'h', '==') #6
Addition_IF_V('c', 'a', 'b') #7
Addition_IF_V('d', 'c', 'x') #8
Addition_IF_V('h', 'e', 'd') #9
# hidden
# value a 10
# value f 11
Else_V("")
Addition_Else_V('a', 'b', 'c') #7
Addition_Else_V('f', 'h', 'z') #8
Addition_Else_V('h', 'a', 'd') #9
# hidden
# value c 10
# value d 11
End_IfElse_V('')

Addition_V('q', 'e', 'f') #12
Addition_V('w', 'h', 'x') #13
#print("Addition_V('h', 'f', 'a')")
Addition_V('h', 'f', 'a') #14
#print("Addition_V('d', 'a', 'b')")
Addition_V('d', 'a', 'b') #15
#print("#14 Addition_V('d', 'a', 'b')")
Addition_V('f', 'g', 'c') #16

If_V("a", 'b', '>=') #17
Addition_IF_V('c', 'b', 'x') #18
# value g 19
# value k 20
#Addition_IF_V('g', 'f', 'd')
#Addition_IF_V('h', 'e', 'd')
Else_V("")
Addition_Else_V('k', 'a', 'h') #18
Addition_Else_V('g', 'f', 'd') #19
# value c 20
#Addition_Else_V('h', 'a', 'd')
End_IfElse_V('')
#print("#18 Addition_V('f', 'g', 'c')")
Addition_V('f', 'g', 'c') #21
#print("#19 Addition_V('r', 'f', 'c')")
Addition_V('r', 'f', 'c') #22

# for i in range(0, 4):
    
#     Addition_Index_V('c', i, 'a', -1, 'b', -1)
#     Addition_Index_V('c', i+1, 'c', i+1, 'c', i)
    


# SinCosTan_Index_V('c', -1, 'a', -1, 'b', -1, 'd', -1)
# SinCosTan_Index_V('c', -1, 'a', -1, 'b', -1, 'd', i)
# SinCosTan_Index_V('c', -1, 'a', -1, 'b', i, 'd', -1)
# SinCosTan_Index_V('c', -1, 'a', -1, 'b', i, 'd', i)
# SinCosTan_Index_V('c', -1, 'a', i, 'b', -1, 'd', -1)
# SinCosTan_Index_V('c', -1, 'a', i, 'b', -1, 'd', i)
# SinCosTan_Index_V('c', -1, 'a', i, 'b', i, 'd', -1)
# SinCosTan_Index_V('c', -1, 'a', i, 'b', i, 'd', i)
# SinCosTan_Index_V('c', i, 'a', -1, 'b', -1, 'd', -1)
# SinCosTan_Index_V('c', i, 'a', -1, 'b', -1, 'd', i)
# SinCosTan_Index_V('c', i, 'a', -1, 'b', i, 'd', -1)
# SinCosTan_Index_V('c', i, 'a', -1, 'b', i, 'd', i)
# SinCosTan_Index_V('c', i, 'a', i, 'b', -1, 'd', -1)
# SinCosTan_Index_V('c', i, 'a', i, 'b', -1, 'd', i)
# SinCosTan_Index_V('c', i, 'a', i, 'b', i, 'd', -1)
# SinCosTan_Index_V('c', i, 'a', i, 'b', i, 'd', i)

# Sqrt_Index_V('b', -1, 'd', -1)
# Sqrt_Index_V('b', -1, 'd', i)
# Sqrt_Index_V( 'b', i, 'd', -1)
# Sqrt_Index_V('b', i, 'd', i)

import lib_para
binary_tree_main = lib_para.Eq_record
counter_all = lib_para.Address_counter
binary_tree_if = lib_para.Eq_record_if_1
counter_if_address = lib_para.Address_counter_if + 1
counter_else_address = lib_para.Address_counter_else + 1
binary_tree_else = lib_para.Eq_record_else_1

storage_binary_tree_if = IfElse_Arrays.if_array
storage_delay_if = IfElse_Arrays.if_delay
storage_delay_else = IfElse_Arrays.else_delay
storage_binary_tree_else = IfElse_Arrays.else_array
if_addresses = IfElse_Arrays.start_address_if
if_count = lib_para.If_counter
else_count = lib_para.Else_counter

from Verilog_Generation import PyToVer
PyToVer("top")

