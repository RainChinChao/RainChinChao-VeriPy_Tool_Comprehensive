# -*- coding: utf-8 -*-
"""
Created on Mon Jun 24 13:48:43 2024

@author: elx22yz
"""


import lib_para
from Template_with_next_stages import dt_next
import numpy as np
from Template_with_next_stages import Max_number_operands  
from Template_with_next_stages import Max_no_next_addreeses  
import itertools

def find_next_eq(a):
    
    counter_all = lib_para.Address_counter
    binary_tree_main = lib_para.Eq_record
    
    for i in range(0, counter_all + 1):
        operands = binary_tree_main[i]['operand_name_array']
        no_operands = binary_tree_main[i]['number_of_operands']        
        operator = binary_tree_main[i]['operator'] 
        results = binary_tree_main[i]['result_name_array']
        no_results = binary_tree_main[i]['number_of_results']
        previous_addresses = binary_tree_main[i]['previous_address']
        no_previous_adresses = binary_tree_main[i]['no_of_previous_address']
        delay_cycles = binary_tree_main[i]['delay cycles']
        
        next_stages = list(itertools.repeat(-1, Max_no_next_addreeses))
        no_next_stages = list(itertools.repeat('0', Max_number_operands))
        
        
        
        
        
        next_stages_counter = 0
        for j in range(0, no_results):
            
            # find the address number next show up
            search_element = results[j]
            no_next_stages_current = 0
            # next show up finder
            for k in range(i + 1, counter_all + 1): 
                
                current_eq = binary_tree_main[k]
                current_eq_operands = current_eq['operand_name_array']
                current_eq_no_operands = current_eq['number_of_operands']      
                
                for l in range(0, current_eq_no_operands):
                    if(search_element == current_eq_operands[l]):
                        next_stages[next_stages_counter] = k
                        next_stages_counter = next_stages_counter + 1                        
                        no_next_stages_current = no_next_stages_current + 1
                        
            no_next_stages[j] =  no_next_stages_current                     
                        
        
        
        
        
        element_of_new = np.array([(operands, no_operands, operator, results, 
                                   no_results, previous_addresses, 
                                   no_previous_adresses, delay_cycles, 
                                   next_stages, no_next_stages)], dtype=dt_next)
        #print(element_of_new)
        if(i == 0):
            #print(element_of_new)
            lib_para.Eq_record_with_next_stage = element_of_new
        else:
            #print(lib_para.Eq_record_with_next_stage)
            lib_para.Eq_record_with_next_stage = np.concatenate((lib_para.Eq_record_with_next_stage, element_of_new), axis=0)
            #print(len(lib_para.Eq_record_with_next_stage))
            
            
        