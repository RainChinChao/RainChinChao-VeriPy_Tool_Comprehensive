# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 13:35:13 2024

@author: elx22yz
"""
''' 25/04/2024
    Version 0.0.1
    This is the function to generate input names to update the lib_para 
    parameters, which could help to print input/output in the top file
    
'''
import lib_para


def input_define(input_name):
    
    
    lib_para.input_names.append(input_name)
    
