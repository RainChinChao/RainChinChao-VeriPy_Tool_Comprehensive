# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 10:40:38 2024

@author: elx22yz
"""
''' 25/04/2024
    Version 0.0.1
    This is the function to generate number in Verilog version from the normal
    Python version.
    
'''



def number_to_hex(number_input):
    
    if(number_input<0):
        number_hex = round(abs(number_input)*pow(2,16))
        text_out = str(4294967296-number_hex)
    else:
        number_hex = round(number_input*pow(2,16))
        text_out = str(number_hex)
    
    
   
    return text_out