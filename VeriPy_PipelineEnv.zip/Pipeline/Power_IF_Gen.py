# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 10:27:16 2024

@author: elx22yz
"""

''' 07/03/2024
    Version 0.0.1
    This is the function to generate Power into the record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''

from Add_Into_Structure_Array_If import Add_Into_Structure_Array_If
import itertools
from Template import Max_number_operands     
from Template import Max_number_results

def Power_IF_V(c, base, exponent):
      
    results = list(itertools.repeat('0', Max_number_results))
    results[0] = c
    inputs = list(itertools.repeat('0', Max_number_operands))
    inputs[0] = base
    inputs[1] = exponent  
    operator_num = 5
    number_of_operands = 2
    number_of_results = 1
    
    Add_Into_Structure_Array_If(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)