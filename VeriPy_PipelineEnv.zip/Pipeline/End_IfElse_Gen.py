# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 10:21:22 2024

@author: elx22yz
"""

''' 19/03/2024
    Version 0.0.1
    This is the function is at the end of the if/else statement to store all 
    the strucutre arrays of if else into a new array. Also, the previous one 
    will be cleared.
    
'''


import numpy as np
from Template import dt
from Template import Max_number_operands     
from Template import Max_number_results 
import lib_para
import IfElse_Arrays
import Else_Gen
from Value_Else_Gen import Value_Else_V
from Value_IF_Gen import Value_IF_V

def End_IfElse_V(c):

    

    
    
    
    
    
    
    
    
    
    import lib_para
    # Calculate the largest delay between if and else
    IfElse_Arrays.if_delay[lib_para.If_counter-1]=lib_para.Address_counter_if+1
    IfElse_Arrays.else_delay[lib_para.If_counter-1]=lib_para.Address_counter_else+1
    
    
    # Record the addresses of if/else statement
    IfElse_Arrays.start_address_if[lib_para.If_counter-1]=lib_para.Address_counter
    
    
    
    
    
    
    if(lib_para.Address_counter_else >= lib_para.Address_counter_if):
        delay = lib_para.Address_counter_else + 1
    else:
        delay = lib_para.Address_counter_if + 1
        
    
    
    
    
    
    lib_para.function_name
    
    from real_binary_tree_est_multiDelay_If import real_binary_tree_est_if
    real_binary_tree_est_if(lib_para.function_name)
    #real_binary_tree_est_if("top")
           
           
    from real_binary_tree_est_multiDelay_Else import real_binary_tree_est_else
    real_binary_tree_est_else(lib_para.function_name)
    #real_binary_tree_est_else("top")
    
    
    
    # Store the temporary if/else arrays into the If/Else Array, store the delay info
    IfElse_Arrays.if_array[lib_para.If_counter- 1] = lib_para.Eq_record_if_1
    
    #print(lib_para.Eq_record_if_1)
    
    IfElse_Arrays.else_array[lib_para.If_counter- 1] = lib_para.Eq_record_else_1
    
    
    
    # deal with the delay problem
    import real_binary_tree_est_multiDelay_If
    import real_binary_tree_est_multiDelay_Else
    if_delay = real_binary_tree_est_multiDelay_If.algorithm_total_delay_array
    else_delay = real_binary_tree_est_multiDelay_Else.algorithm_total_delay_array
    
    max_delay = 0
    delay_difference = abs(if_delay[0] - else_delay[0])
    
    
    if_print = str(lib_para.If_counter-1)
    
    if_verilog_file_name = 'if_' + lib_para.function_name + '_V_' + if_print + '.v'
    f = open(if_verilog_file_name, "a")
    
    
    # When else need extra delays
    if(if_delay > else_delay):
        max_delay = if_delay
        
        
        before_delay_name = "res_else_before_delay"
        after_delay_name = "res_else_after_delay"
        current_level = if_print
        
        
        # Assign if function result
        f.write("\tassign res_if_after_delay = res_if_before_delay;\n")
        
        # Delay the else function result
        for i in range (0, delay_difference):
            
            # When there is only 1 delay needed
            if(delay_difference == 1):
                input_name_0_delay = before_delay_name
                result_name_delay = after_delay_name
                
                f.write("\twire [31:0]" + result_name_delay + ";\n")
                
                f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                        + "_"  + str(i) + "_" + after_delay_name 
                        + " ( clk, reset, " + input_name_0_delay + 
                        ", " + result_name_delay + ");\n")
                                                              
            else: 
                # For the first appearance, print input is the original input
                if(i == 0):
                    
                    input_name_0_delay = before_delay_name
                    result_name_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i)
                    
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name 
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
                    
                                                
                # For the last appearance, print input is the current input
                elif(i == delay_difference - 1):
                    input_name_0_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i - 1)
                    result_name_delay = after_delay_name
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name 
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
                   
                    
                else:
                    input_name_0_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i - 1)
                    result_name_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i)
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    # When if need extra delays
    elif(if_delay < else_delay):
        max_delay = else_delay
        
        
        
        before_delay_name = "res_if_before_delay"
        after_delay_name = "res_if_after_delay"
        current_level = if_print
        
        
        # Assign if function result
        f.write("\tassign res_else_after_delay = res_else_before_delay;\n")
        
        # Delay the else function result
        for i in range (0, delay_difference):
            
            # When there is only 1 delay needed
            if(delay_difference == 1):
                input_name_0_delay = before_delay_name
                result_name_delay = after_delay_name
                
                f.write("\twire [31:0]" + result_name_delay + ";\n")
                
                f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                        + "_"  + str(i) + "_" + after_delay_name 
                        + " ( clk, reset, " + input_name_0_delay + 
                        ", " + result_name_delay + ");\n")
                                                              
            else: 
                # For the first appearance, print input is the original input
                if(i == 0):
                    
                    input_name_0_delay = before_delay_name
                    result_name_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i)
                    
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name 
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
                    
                                                
                # For the last appearance, print input is the current input
                elif(i == delay_difference - 1):
                    input_name_0_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i - 1)
                    result_name_delay = after_delay_name
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name 
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
                   
                    
                else:
                    input_name_0_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i - 1)
                    result_name_delay = before_delay_name + "delay_Level_If_V_" + str(current_level) + "_delay_"  + str(i)
                    f.write("\twire [31:0]" + result_name_delay + ";\n")
                    
                    f.write("\tdelay "+ "delay_Level_If_V_" + str(current_level) 
                            + "_"  + str(i) + "_" + after_delay_name
                            + " ( clk, reset, " + input_name_0_delay + 
                            ", " + result_name_delay + ");\n")
        
        
        
        
        
    # When both delay are the same
    else:
        max_delay = else_delay
        f.write("\tassign res_else_after_delay = res_else_before_delay;\n")
        f.write("\tassign res_if_after_delay = res_if_before_delay;\n")
        
        
        
        
        
        
        

        
        
        
        
        
        
        
    
    #print(max_delay)
    
    lib_para.Eq_record[lib_para.Address_counter]['delay cycles'] = max_delay[0]
    
    
    
    
    
    
    
    
    
    
    
    
    f.write("endmodule\n")
    f.close()
        
    
    
    
    # Initialize the if/else arrays
    lib_para.Eq_record_if_1 = np.array([(lib_para.Initial_inputs_names, 0, 0, 
                                lib_para.Initial_results_names, 0, 
                                lib_para.Initial_previous_addresses, lib_para.Initial_no_of_previous_addresses  
                                ,0)],          
                                dtype=dt)
    
    
    
    lib_para.Eq_record_else_1 = np.array([(lib_para.Initial_inputs_names, 0, 0, 
                                  lib_para.Initial_results_names, 0, 
                                  lib_para.Initial_previous_addresses, lib_para.Initial_no_of_previous_addresses  
                                  ,0)],          
                                         dtype=dt)
    
    
    # Initialize the address counter in if/else
    lib_para.Address_counter_else = -1
    lib_para.Address_counter_if = -1
    
    
    # Initialize the input/output names
    lib_para.input_names_ifelse = []

    lib_para.output_names_ifelse = []
    
    