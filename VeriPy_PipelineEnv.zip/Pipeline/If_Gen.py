# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 09:49:36 2024

@author: elx22yz
"""
''' 07/03/2024
    Version 0.0.1
    This is the function to generate If into a new record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''


from Add_Into_Structure_Array import Add_Into_Structure_Array
import itertools
from Template import Max_number_operands     
from Template import Max_number_results
from Template import dt
import lib_para


def If_V(a, b, condition, input_name_array, output_name):
    
    
    
    
    # Store input/output names into lib_para
    # including figures numbers
    lib_para.input_names_ifelse.append(a)
    lib_para.input_names_ifelse.append(b)
    
    for i in range(0, len(input_name_array)):
        lib_para.input_names_ifelse.append(input_name_array[i])
    
    lib_para.output_names_ifelse = [output_name]
    
    
    
    
    
    
    
    
    
    #lib_para.Address_counter = lib_para.Address_counter +  1
    #print(lib_para.Address_counter)
    # Initialize the if structure array
    lib_para.Address_counter_if = -1
    
    # Count a how many if else we have
    lib_para.If_counter = lib_para.If_counter + 1
    new_If_counter = str(lib_para.If_counter)
    if_print = str(lib_para.If_counter-1)
    # reg_name = "if_condition_" + new_If_counter
    
    if_print = str(lib_para.If_counter-1)
    
    if_verilog_file_name = 'if_' + lib_para.function_name + '_V_' + if_print + '.v'
    f = open(if_verilog_file_name, "w")
    
    # Print title
    f.write("module if_" + lib_para.function_name + '_V_' + if_print)
    
    
   
    if(a.isnumeric()):
        a_part = ""
    else:
        a_part = "input [31:0]" + a + ", "
    
    if(b.isnumeric()):
        b_part = ""
    else:
        b_part = "input [31:0]" + b + ", "
    
    
    define_a_b = a_part + b_part
    
    
    # Print the input of conditions and conctol signals
    f.write("( input clk, input reset, "            
            + define_a_b )
    
    
    for i in range(0, len(input_name_array)):
    
        f.write("input [31:0]"            
                + input_name_array[i] +  ", ")

    f.write( " output [31:0]" + output_name +"_if_V" 
            + if_print + ");\n\n")

   
    
    
    # for delay before and after results from both if and else
    f.write("\twire [31:0]res_if_after_delay;\n")
    f.write("\twire [31:0]res_if_before_delay;\n")
    f.write("\twire [31:0]res_else_after_delay;\n")
    f.write("\twire [31:0]res_else_before_delay;\n")
    
    # For register output
    f.write("\treg [31:0]" + output_name + "_reg;\n")
    f.write("\tassign " + output_name +"_if_V" 
            + if_print + " = " + output_name + "_reg;\n\n\n\n")


    
    # If function
    f.write("\tIf_" + lib_para.function_name + "_V_" + if_print + "_if_calculation"
            + " If_" + lib_para.function_name + "_V_" + if_print + "_if_calculation1"
            +"( ")
    
    if(a.isnumeric()):
        a_part = ""
    else:
        f.write(a + ", ")
        
    
    if(b.isnumeric()):
        b_part = ""
    else:
        f.write(b + ", ")
    
    for i in range(0, len(input_name_array)):
    
        f.write(input_name_array[i] +  ", ")
    
    f.write("res_if_before_delay, clk, reset);\n")
    
    
    # Else function
    f.write("\tIf_" + lib_para.function_name + "_V_" + if_print + "_else_calculation"
            + " If_" + lib_para.function_name + "_V_" + if_print + "_else_calculation1"
            +"( ")
    
    if(a.isnumeric()):
        a_part = ""
    else:
        f.write(a + ", ")
        
    
    if(b.isnumeric()):
        b_part = ""
    else:
        f.write(b + ", ")
        
    for i in range(0, len(input_name_array)):
    
        f.write(input_name_array[i] +  ", ")
    
    f.write("res_else_before_delay, clk, reset);\n")
    
    
    
    
    

    # Always function to choose final result
    f.write("\talways@(posedge clk)begin\n")
    f.write("\t\tif(reset)begin\n")

    f.write("\t\t\t" + output_name + "_reg <= 0;\n")
    f.write("\t\tend else begin\n")

    
    f.write("\t\t\tif(" + a + condition + b +
    ") begin\n" + 
    "\t\t\t\t" +
    output_name + "_reg <= " + "res_if_after_delay;"
    "\n\t\t\tend"+
    " else begin\n"+
    "\t\t\t\t"+
    output_name + "_reg <= " + "res_else_after_delay;"
    )
    

    f.write("\n\t\t\tend\n")
    f.write("\t\tend\n")
    
    f.write("\tend\n\n\n\n")
    
    
    

    #f.write("endmodule\n")
    f.close()
    results = list(itertools.repeat('0', Max_number_results))
    inputs = list(itertools.repeat('0', Max_number_operands))
    # For if/else condition
    inputs[0] = a
    inputs[1] = b
    
    for i in range(0, len(input_name_array)):
        inputs[i + 2] = input_name_array[i]
    
    operator_num = 10
    number_of_operands = 2 + len(input_name_array)
    
    results[0] = output_name
    number_of_results = 1
    
    Add_Into_Structure_Array(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)