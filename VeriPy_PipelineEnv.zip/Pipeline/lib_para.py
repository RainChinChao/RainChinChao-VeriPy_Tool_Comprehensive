# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 10:16:03 2024

@author: elx22yz
"""
import numpy as np
from Template import dt
from Template import Max_number_operands     
from Template import Max_number_results  
from Template import Max_no_previous_addreeses     
Address_counter = -1

import itertools

from Template_with_next_stages import dt_next
from Template_with_next_stages import Max_number_results  
from Template_with_next_stages import Max_no_next_addreeses    

# For array Define

array_names = []
array_sizes = []


input_names = []
output_names = []


function_name = ""







Initial_inputs_names = list(itertools.repeat('0', Max_number_operands))
Initial_results_names = list(itertools.repeat('0', Max_number_results))
Initial_previous_addresses = list(itertools.repeat(-1, Max_no_previous_addreeses))
Initial_no_of_previous_addresses = list(itertools.repeat('0', Max_number_operands))

Initial_next_addresses = list(itertools.repeat(-1, Max_no_next_addreeses))
Initial_no_of_next_addresses = list(itertools.repeat('0', Max_number_operands))


Eq_record = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses,Initial_no_of_previous_addresses, 0)],          
                        dtype=dt)

Eq_record_with_next_stage = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses,Initial_no_of_previous_addresses, 0, 
                       Initial_next_addresses, Initial_no_of_next_addresses)],          
                        dtype=dt_next)

# Count how many if we are having now
If_counter = 0
Else_counter = 0
# These 2 are for counting address inside if/else structure array
Address_counter_else = -1
Address_counter_if = -1
Eq_record_if_1 = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses, Initial_no_of_previous_addresses, 0)],          
                        dtype=dt)


Eq_record_else_1 = np.array([(Initial_inputs_names, 0, 0, Initial_results_names, 0, 
                       Initial_previous_addresses,Initial_no_of_previous_addresses, 0)],          
                        dtype=dt)



input_names_ifelse = []
output_names_ifelse = []

