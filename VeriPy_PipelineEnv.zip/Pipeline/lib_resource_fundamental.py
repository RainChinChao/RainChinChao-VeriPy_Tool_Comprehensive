# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 15:57:14 2024

@author: elx22yz
"""

"""
14/06/2024

This library is to store the resource usage of fundamental functions.

"""


LUT_array = [0, 48, 111, 311, 2308, 2507, 13952, 366, 10193, 32, 18]
FF_array = [0, 32, 32, 32, 32, 0, 132, 16, 92, 0, 1]
DSP_array = [0, 0, 0, 4, 0, 112, 0, 0, 75, 0, 0]
BRAM_array = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

