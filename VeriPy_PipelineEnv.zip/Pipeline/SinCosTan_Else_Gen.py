# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 11:24:11 2024

@author: elx22yz
"""

''' 06/03/2024
    Version 0.0.1
    This is the function to generate sincostan into the record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''

from Add_Into_Structure_Array_Else import Add_Into_Structure_Array_Else
import itertools
from Template import Max_number_operands     
from Template import Max_number_results

def SinCosTan_Else_V(sin_r, cos_r, tan_r, a):
      
    results = list(itertools.repeat('0', Max_number_results))
    results[0] = sin_r
    results[1] = cos_r
    results[2] = tan_r
    inputs = list(itertools.repeat('0', Max_number_operands))
    inputs[0] = a  
    operator_num = 8
    number_of_operands = 1
    number_of_results = 3
    
    Add_Into_Structure_Array_Else(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)
