from Add_Into_Structure_Array_If import Add_Into_Structure_Array_If
import itertools
from Template import Max_number_operands
from Template import Max_number_results
def MAC_16_x_15_IF_V(output_0,input_0,input_1,input_2,input_3,input_4,input_5,input_6,input_7,input_8,input_9,input_10,input_11,input_12,input_13,input_14,input_15):
	results = list(itertools.repeat('0', Max_number_results))
	inputs = list(itertools.repeat('0', Max_number_results))
	results[0] = output_0
	inputs[0] = input_0
	inputs[1] = input_1
	inputs[2] = input_2
	inputs[3] = input_3
	inputs[4] = input_4
	inputs[5] = input_5
	inputs[6] = input_6
	inputs[7] = input_7
	inputs[8] = input_8
	inputs[9] = input_9
	inputs[10] = input_10
	inputs[11] = input_11
	inputs[12] = input_12
	inputs[13] = input_13
	inputs[14] = input_14
	inputs[15] = input_15

	operator_num =1006
	number_of_operands = 16
	number_of_results =1
	Add_Into_Structure_Array_If(results, inputs, operator_num, number_of_operands, number_of_results, 17)