# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 16:21:39 2024

@author: elx22yz
"""
"""
14/06/2024

This function is to estimate the resource usage

"""



import lib_para
import lib_resource_fundamental
import lib_resource_newfun
import IfElse_Arrays
def res_esti(a):
    
    binary_tree_main = lib_para.Eq_record
    counter_all = lib_para.Address_counter
    
    LUT = 0
    FF = 0
    DSP = 0
    BRAM = 0
    
    
    
    for i in range(0, counter_all + 1):
        #print(LUT)
        operator = binary_tree_main[i]['operator'] 
        if(operator<1000 and operator>0):
            LUT = LUT + lib_resource_fundamental.LUT_array[operator]
            FF = FF + lib_resource_fundamental.FF_array[operator]
            DSP = DSP + lib_resource_fundamental.DSP_array[operator]
            BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
        elif(operator>=1000):
            LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
            FF = FF + lib_resource_newfun.FF_array[operator-1000]
            DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
            BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]
    

    # If Else Array
    for i in range(0, lib_para.If_counter):
        for j in range (0, len(IfElse_Arrays.if_array[i])):
            operator = IfElse_Arrays.if_array[i][j]['operator'] 
            
            if(operator<1000 and operator>0):
                
                LUT = LUT + lib_resource_fundamental.LUT_array[operator]
                FF = FF + lib_resource_fundamental.FF_array[operator]
                DSP = DSP + lib_resource_fundamental.DSP_array[operator]
                BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
            elif(operator>=1000):
                
                LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
                FF = FF + lib_resource_newfun.FF_array[operator-1000]
                DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
                BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]
            
            
    # Else Else Array
    for i in range(0, lib_para.If_counter):      
        for j in range (0, len(IfElse_Arrays.else_array[i])):
              operator = IfElse_Arrays.else_array[i][j]['operator'] 
              if(operator<1000 and operator>0):
                  LUT = LUT + lib_resource_fundamental.LUT_array[operator]
                  FF = FF + lib_resource_fundamental.FF_array[operator]
                  DSP = DSP + lib_resource_fundamental.DSP_array[operator]
                  BRAM = BRAM + lib_resource_fundamental.BRAM_array[operator]
              elif(operator>=1000):
                  LUT = LUT + lib_resource_newfun.LUT_array[operator-1000]
                  FF = FF + lib_resource_newfun.FF_array[operator-1000]
                  DSP = DSP + lib_resource_newfun.DSP_array[operator-1000]
                  BRAM = BRAM + lib_resource_newfun.BRAM_array[operator-1000]      
            
    sentence = "The resources of " + a + " consuming are shown as below:"
    print(sentence)
    LUT_sen = "LUT: " + str(LUT)
    FF_sen = "FF: " + str(FF)
    DSP_sen = "DSP: " + str(DSP)
    BRAM_sen = "BRAM: " + str(BRAM)
    
    print(LUT_sen)
    print(FF_sen)
    print(DSP_sen)
    print(BRAM_sen)
    
    print("This is the end of the resource consumption reports.")
    