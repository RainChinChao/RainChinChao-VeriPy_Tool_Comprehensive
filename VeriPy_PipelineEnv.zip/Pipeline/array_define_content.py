# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 13:45:14 2024

@author: elx22yz
"""





import lib_reg







def array_define_content(array_name, array_itself):
    
    lib_reg.reg_array_names.append(array_name)
    lib_reg.reg_array_list[lib_reg.reg_array_counter] = array_itself
    
    lib_reg.reg_array_counter = lib_reg.reg_array_counter + 1
    
    
    
    
    
    
    



# a = [1, 2, 6, 4, 8]
# b = [1, 2, 2]

# array_define_content("a", a)
# array_define_content("b", b)


# from array_content_print_top import array_content_print_top

# array_content_print_top("test.v")

# list_array = lib_reg.reg_array_list
# list_names = lib_reg.reg_array_names
# list_counter = lib_reg.reg_array_counter