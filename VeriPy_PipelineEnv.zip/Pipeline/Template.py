# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 09:39:56 2024

@author: elx22yz
"""

''' 28/02/2024
    Version 0.1.0
    In this version, an array based structure is generated. By this progress,
    the operands_name, results_name and, previous addresses could be set to an array.
    Then the structure could be more clear.
    
    28/02/2024
    Version 0.0.1
    This function is a template for every existing fundamental functions of +, 
    -, *, /, sin/cos/tan, power, sqrt, log, value(賦值).
    By using this temmplate, a structure/class containing operant, operator,
    result, previous address(could be 2), number of operants, and number of 
    results(this one is currently optional)
'''

import numpy as np
counter_no_of_eq = 0

Max_number_operands     = 20
Max_number_results      = 20
Max_name_length         = 30
Max_no_previous_addreeses = 100
dt= np.dtype([
              ('operand_name_array', ((np.str_, Max_name_length), Max_number_operands)), 
              # Length of operands' names could not exceed 10 characters
              # Number of operands' names could not exceed 20
              # Index of the array from 0
              ('number_of_operands', (np.int8)),
              # This is for more than one operands
              ('operator', np.int32),
              # 1 +, 2 -, 3 *, 4 /, 5 power, 6 log, 7 sqrt, 8 sin/cos/tan, 
              # 9 value(賦值), 10 If/Else 
              ('result_name_array', ((np.str_, Max_name_length), Max_number_results)),
              # Length of results' names could not exceed 10 characters
              # Number of results' names could not exceed 20
              ('number_of_results', (np.int8)),
              # This is for more than one results
              ('previous_address', (np.int32, Max_no_previous_addreeses)),
              # This is for operands last finished operation equation addresses
              # The number of previous addresses should be equal to the number 
              # of operands.
              # Index of the array from 0
              ('no_of_previous_address', (np.int32, Max_number_operands)),
              ('delay cycles', (np.int8))
              ]) 
# Index of the array from 0

'''a = np.array([(['a','b'], 2, 1, 'b', 2, [1,2])], dtype=dt) 


print(a[0]['operand_name_array'][0])

'''