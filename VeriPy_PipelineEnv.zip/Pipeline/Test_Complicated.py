# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 09:52:46 2024

@author: elx22yz
"""

''' 29/02/2024
    Version 0.0.1
    This is the function the main function that calls all kinds of generation 
    functions like Addition_V, Multi_V, etc.
'''

import numpy as np
from Template import dt
#from Addition_Gen import Addition_V
from SinCosTan_Gen import SinCosTan_V
from Addition_Gen import Addition_V
from Logarithm_Gen import Logarithm_V
from Division_Gen import Division_V
from Multiplication_Gen import Multiplication_V
from Power_Gen import Power_V
from Sqrt_Gen import Sqrt_V
from Subtraction_Gen import Subtraction_V
from Value_Gen import Value_V
import lib_para
lib_para.Address_counter = -1
# Initialize Address_counter = 0


'''
Addition_V1('c', 'a', 'b')
Addition_V1('f', 'a', 'c')
Addition_V1('g', 'a', 'f')
Addition_V1('h', 'f', 'c')
Addition_V1('x', 'y', 'z')
'''

'''
Addition_V('c', 'a', 'b')
SinCosTan_V('x', 'y', 'z', 'c')
Addition_V('d', 'x', 'a')

Addition_V('e', 'd', 'y')
Addition_V('f', 'e', 'z')
Addition_V('h', 'f', 'g')
'''

# Test for complicated equation
# (Asin(w1x+T1)+log10(cos(w2x+T2)))/sqrt(MKN)+power(B,N)


import lib_para
lib_para.function_name = "top"




from input_define import input_define
from output_define import output_define
from number_to_hex_Input import number_to_hex
input_define("w1")
input_define("x")
input_define("T1")
input_define("A") 
input_define("w2")
input_define("T2")
input_define("M")
input_define("K")
input_define("N")
input_define("B")
input_define("N_power")
output_define("Add_all")






# Asin(w1x+T1)
Multiplication_V('w1x', 'w1', 'x')
Addition_V('w1x_T1', 'w1x', 'T1')
SinCosTan_V('sin_w1x_T1', 'cos_w1x_T1', 'tan_w1x_T1', 'w1x_T1')
Multiplication_V('A_sin', 'A', 'sin_w1x_T1')

# log10(cos(w2x+T2))
Multiplication_V('w2x', 'w2', 'x')
Addition_V('w2x_T2', 'w2x', 'T2')
SinCosTan_V('sin_w2x_T2', 'cos_w2x_T2', 'tan_w2x_T2', 'w2x_T2')
Logarithm_V('log', number_to_hex(10), 'cos_w2x_T2')

# sqrt(MKN)
Multiplication_V('MK', 'M', 'K')
Multiplication_V('MKN', 'MK', 'N')
Sqrt_V('sqrt', 'MKN')

# (Asin(w1x+T1) + log10(cos(w2x+T2)))/sqrt(MKN)
Addition_V('Add_part', 'A_sin', 'log')
Division_V('Div', 'Add_part', 'sqrt')

# power(B,N)
Power_V('BN_power', 'B', 'N_power')


# (Asin(w1x+T1) + log10(cos(w2x+T2)))/sqrt(MKN) + power(B,N)
Addition_V('Add_all', 'Div', 'BN_power')
















import real_binary_tree_est_multiDelay
pure_previous_address = real_binary_tree_est_multiDelay.previous_addresses_array
#print(pure_previous_address)

from real_binary_tree_est_multiDelay import real_binary_tree_est
real_binary_tree_est("ComplicatedFun")
recall_level =  real_binary_tree_est_multiDelay.recall_level

temp_array_tree = real_binary_tree_est_multiDelay.temp_array_tree

tree_0 = real_binary_tree_est_multiDelay.tree_0










# #cc_with_next = lib_para.Eq_record_with_next_stage
# counter__=lib_para.Address_counter

# from find_next_eq import find_next_eq
# find_next_eq(1)
# import lib_para
# Eq_record = lib_para.Eq_record
# Eq_record_with_next = lib_para.Eq_record_with_next_stage
# result_names = lib_para.output_names




# import real_binary_tree_est
# pure_previous_address = real_binary_tree_est.previous_addresses_array
# #print(pure_previous_address)

# from real_binary_tree_est import real_binary_tree_est
# real_binary_tree_est("top")
# import real_binary_tree_est
# recall_level =  real_binary_tree_est.recall_level

# temp_array_tree = real_binary_tree_est.temp_array_tree

# tree_0 = real_binary_tree_est.tree_0
# tree_1 = real_binary_tree_est.tree_1
# tree_2 = real_binary_tree_est.tree_2
# tree_3 = real_binary_tree_est.tree_3
# tree_4 = real_binary_tree_est.tree_4

# #print(real_binary_tree_est.level_no_max + 1)




















# #cc_with_next = lib_para.Eq_record_with_next_stage
# counter__=lib_para.Address_counter

# from find_next_eq import find_next_eq
# find_next_eq(1)
# import lib_para
# Eq_record = lib_para.Eq_record
# Eq_record_with_next = lib_para.Eq_record_with_next_stage
# result_names = lib_para.output_names




# import real_binary_tree_est
# pure_previous_address = real_binary_tree_est.previous_addresses_array
# #print(pure_previous_address)

# from real_binary_tree_est import real_binary_tree_est
# real_binary_tree_est("top")
# import real_binary_tree_est
# recall_level =  real_binary_tree_est.recall_level

# temp_array_tree = real_binary_tree_est.temp_array_tree

# tree_0 = real_binary_tree_est.tree_0
# tree_1 = real_binary_tree_est.tree_1
# tree_2 = real_binary_tree_est.tree_2
# tree_3 = real_binary_tree_est.tree_3
# tree_4 = real_binary_tree_est.tree_4

# #print(real_binary_tree_est.level_no_max + 1)
