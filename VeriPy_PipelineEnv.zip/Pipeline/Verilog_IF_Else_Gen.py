# -*- coding: utf-8 -*-
"""
Created on Mon Apr 15 16:32:19 2024

@author: elx22yz
"""


import numpy as np
from Template import dt
import IfElse_Arrays
import lib_para
import lib_in_out_names
 # define result names
# result_names_if = []
# result_name_no_if = []
# result_names_counter_if = 0
 
# result_names_else = []
# result_name_no_else = []
# result_names_counter_else = 0
if_input_names = []
else_input_names = []
    
if_else_output_names = []


def result_name_adder(na, file_name):
    # global result_names_counter_if
    # global result_name_no_if
    # global result_names_if
    
    if(lib_in_out_names.result_names_counter_if == 0):
        lib_in_out_names.result_names_if.append(str(na))
        lib_in_out_names.result_name_no_if.append(1)
        lib_in_out_names.result_names_counter_if = lib_in_out_names.result_names_counter_if + 1
        new_result_name = na
    else:
        flag = 0
        for j in range (0, lib_in_out_names.result_names_counter_if):
            if(lib_in_out_names.result_names_if[j] == str(na)):
                flag = 1
                temp_j = j
                break
        
        if(flag == 1):
            lib_in_out_names.result_name_no_if[temp_j] = lib_in_out_names.result_name_no_if[temp_j] + 1
            new_result_name = str(na) + "_gen_new_" + str(lib_in_out_names.result_name_no_if[temp_j])
            
            
            
            
        else:
            lib_in_out_names.result_names_if.append(str(na))
            lib_in_out_names.result_name_no_if.append(1)
            lib_in_out_names.result_names_counter_if = lib_in_out_names.result_names_counter_if + 1
            new_result_name = na
            
    
        #lib_in_out_names.result_names_if.append(new_result_name)
    
    f = open(file_name, "a")
    
    f.write("\twire [31:0]"+ new_result_name +";\n"                                
                  )
    f.close()
    #print(new_result_name)
    return new_result_name



def input_name_decider(input_name, file_name):
    # global result_names_counter_if
    # global result_name_no_if
    # global result_names_if
    # global if_input_names
    new_input_name = input_name
    for j in range (0, lib_in_out_names.result_names_counter_if):
        if(lib_in_out_names.result_names_if[j] == str(input_name)):
            if(lib_in_out_names.result_name_no_if[j] == 1):
                new_input_name = lib_in_out_names.result_names_if[j]
            else:
                new_input_name = str(input_name) + "_gen_new_" + str(lib_in_out_names.result_name_no_if[j])     
            #if_input_names.append(new_input_name)
    return new_input_name








def result_name_adder_else(na, file_name):
    # global result_names_counter_else
    # global result_name_no_else
    # global result_names_else
    
    if(lib_in_out_names.result_names_counter_else == 0):
        lib_in_out_names.result_names_else.append(str(na))
        lib_in_out_names.result_name_no_else.append(1)
        lib_in_out_names.result_names_counter_else = 1
        new_result_name = na
    else:
        flag = 0
        for j in range (0, lib_in_out_names.result_names_counter_else):
            if(lib_in_out_names.result_names_else[j] == str(na)):
                flag = 1
                temp_j = j
                break
        
        if(flag == 1):
            lib_in_out_names.result_name_no_else[temp_j] = lib_in_out_names.result_name_no_else[temp_j] + 1
            new_result_name = str(na) + "_gen_new_" + str(lib_in_out_names.result_name_no_else[temp_j])
            
            
            
            
        else:
            lib_in_out_names.result_names_else.append(str(na))
            lib_in_out_names.result_name_no_else.append(1)
            lib_in_out_names.result_names_counter_else = lib_in_out_names.result_names_counter_else + 1
            new_result_name = na
            
    
        #lib_in_out_names.result_names_else.append(new_result_name)
    
    f = open(file_name, "a")
    
    f.write("\twire [31:0]"+ new_result_name +";\n"                                
                  )
    f.close()
    return new_result_name



def input_name_decider_else(input_name, file_name):
    # global result_names_counter_else
    # global result_name_no_else
    # global result_names_else
    # global if_input_names
    new_input_name = input_name
    for j in range (0, lib_in_out_names.result_names_counter_else):
        if(lib_in_out_names.result_names_else[j] == str(input_name)):
            if(lib_in_out_names.result_name_no_else[j] == 1):
                new_input_name = lib_in_out_names.result_names_else[j]
            else:
                new_input_name = str(input_name) + "_gen_new_" + str(lib_in_out_names.result_name_no_else[j])     
            #if_input_names.append(new_input_name)
    return new_input_name









# This function is for if to generate a separated module outside the whole module
# This function is for if to generate a separated module outside the whole module
def if_module_gen(if_no, file_name):
    
    
    

    
    
    # Initialize the count of different equations
    add_count = 0
    substract_count = 0
    mul_count = 0
    div_count = 0
    power_count = 0
    log_count = 0
    sqrt_count = 0
    sincostan_count = 0
    value_count = 0
    
    
    # # Code the beginning of the Verilog File
    # f = open(file_name, "a")
    # f.write("module " + "if_inside" + str(if_no) + "(input output)\n")
    # f.close()
    
    
    
    lib_in_out_names.result_names_if = []
    lib_in_out_names.result_name_no_if = []
    lib_in_out_names.result_names_counter_if = 0
     
    
    
    
   
    
    
    if_array = IfElse_Arrays.if_array[if_no]
    else_array = IfElse_Arrays.else_array[if_no]
    delay_if_cycle = IfElse_Arrays.if_delay[if_no]
    delay_else_cycle = IfElse_Arrays.else_delay[if_no]
    start_address = IfElse_Arrays.start_address_if[if_no]
    
    
    # # define result names
    # result_names_if = []
    # result_name_no_if = []
    # result_names_counter_if = 0
    
    # result_names_else = []
    # result_name_no_else = []
    # result_names_counter_else = 0

    
    # Generate if module
    for i in range (0, delay_if_cycle):
        operands = if_array[i]['operand_name_array']
        no_operands = if_array[i]['number_of_operands']        
        operator = if_array[i]['operator'] 
        results = if_array[i]['result_name_array']
        no_results = if_array[i]['number_of_results']
        previous_addresses = if_array[i]['previous_address']
        no_previous_adresses = if_array[i]['no_of_previous_address']
        delay_cycles = if_array[i]['delay cycles']
        
        
        
        
        
        
        
        # Judge if input's previous address is before the if
        global if_input_names
        for j in range (0, no_operands):
            # when the previous address is before if start address
            # flag = 1
            flag_before = 0
            flag_iterative = 0
            if(operands[j].isnumeric()):
                if(j == 0):
                    previous_array_start = 0
                    previous_array_end = no_previous_adresses[j]
                else:
                    previous_array_start = previous_array_end
                    previous_array_end = no_previous_adresses[j] + previous_array_end
            else:
                flag_before = 0
                if(j == 0):
                    previous_array_start = 0
                    previous_array_end = no_previous_adresses[j]
                else:
                    previous_array_start = previous_array_end
                    previous_array_end = no_previous_adresses[j] + previous_array_end
                    
                for k in range (previous_array_start, previous_array_end):
                    if(previous_addresses[k]<start_address):
                        flag_before = 1
                
                # If this oprand is from outside if, then it should be an input
                if(flag_before == 1):
                    flag_iterative = 0
                    for l in range (0, len(if_input_names)):
                        if(if_input_names[l] == operands[j]):
                            flag_iterative = 1
                    if(flag_iterative == 0):
                        if_input_names.append(operands[j])





        match operator:
                case 0:
                    
                    do = 0
                    
                case 1:
                    name_comp = "addition_HDL_" + str(add_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1], file_name)
                    result_name_ = result_name_adder(results[0], file_name)
                    #print(result_name_)
                    
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " + " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\taddition_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    
                    f.close()
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    add_count = add_count + 1
                
                
                
                
                
                
                
                # -
                case 2:
                    name_comp = "subtraction_HDL_" + str(substract_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1], file_name)
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " - " +  input_name_1 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tSubtraction_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    substract_count = substract_count + 1           
                
                
                
                
                
                
                
                
                
                # *
                case 3:
                    name_comp = "mul_HDL_" + str(mul_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1], file_name)
                    result_name_ = result_name_adder(results[0], file_name)
                    #print(result_name_)
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " * " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\tmul_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    mul_count = mul_count + 1
            
            
            
            
            
            
            
            
            
            
            
                # /
                case 4:
                    name_comp = "division_HDL_" + str(div_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1], file_name)
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " / " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tDivision_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    div_count = div_count + 1
                
                
                
                
                
                
                
                
                
                # Power
                case 5:
                    name_comp = "power_HDL_" + str(power_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1], file_name)
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = Pow("
                            + input_name_0 + ", " +  input_name_1 + ")\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tPower_PN "+ name_comp +"( clk, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    power_count = power_count + 1
                
                
                
                
                
                
                
                
                
                
                # Log
                case 6:
                    name_comp = "log_HDL_" + str(log_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    input_name_1 = input_name_decider(operands[1],file_name)
                    result_name_ = result_name_adder(results[0],file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = log"
                            + input_name_0 + " ( " +  input_name_1 + ")\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tlog_inout "+ name_comp + "( " + start_line_name
                            + ", clk, reset, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            "," + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    
                    log_count = log_count + 1
                
                
                
                
                
                
                
                # SQRT
                case 7:
                    name_comp = "sqrt_HDL_" + str(sqrt_count)
                    
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    #input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = sqrt( "
                            + input_name_0 + " )\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tsqrt "+ name_comp + " ( clk, " + input_name_0 +
                            ", " + start_line_name
                            + ", reset, " + result_name_ + 
                            ", " + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sqrt_count = sqrt_count + 1
                
                
                
                
                
                
                # SinCosTan
                case 8:
                    name_comp = "sincostan_HDL_" + str(sincostan_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider(operands[0], file_name)
                    #input_name_1 = input_name_decider(operands[1])                   
                    result_name_0 = result_name_adder(results[0], file_name)
                    result_name_1 = result_name_adder(results[1], file_name)
                    result_name_2 = result_name_adder(results[2], file_name)
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_0 + " = sin("
                            + input_name_0 + ")\n \t//" + result_name_1 + " = cos("
                            + input_name_0 + ")\n \t//"+ result_name_2 + " = tan("
                            + input_name_0 + ")\n "
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\ttan_inout "+ name_comp + " ( clk, " + input_name_0 + 
                            ", " + result_name_0 + ", " + result_name_1 + ", " 
                            + result_name_2 + ", " + start_line_name
                            + ", reset, " + valid_line_name +
                            ", " + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sincostan_count = sincostan_count + 1
                
                
                
                
                
                
                
                
                
                
                # Value / Delay
                case 9:
                    name_comp = "Value_HDL_" + str(value_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    if(operands[0] ==results[0]):
                        
                        input_name_0 = result_name_adder(operands[0], file_name)
                        result_name_ = result_name_adder(results[0], file_name)
                    else:
                        input_name_0 = input_name_decider(operands[0], file_name)
                        
                        result_name_ = result_name_adder(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tdelay "+ name_comp + " (" + start_line_name
                            +", clk, reset, " + input_name_0 + 
                            ", " + result_name_ + ", " + busy_line_name 
                            +", " + valid_line_name +
                             ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_if_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    value_count = value_count + 1
                    
                    
                    
                    
                    
                    
                
                
                
                
                
                
                
                
                
                
                
                case _:
                    print("No such function")
    
    
    
    
    
    
    f = open(file_name, "a")
    f.write("endmodule")
    f.close()






def else_module_gen(if_no, file_name):
    
    
    
    
    
    
    # Initialize the count of different equations
    add_count = 0
    substract_count = 0
    mul_count = 0
    div_count = 0
    power_count = 0
    log_count = 0
    sqrt_count = 0
    sincostan_count = 0
    value_count = 0
    
    
    # Code the beginning of the Verilog File
    # f = open(file_name, "a")
    # f.write("module " + "if_inside" + str(if_no) + "(input output)\n")
    # f.close()
    
    
    lib_in_out_names.result_names_else = []
    lib_in_out_names.result_name_no_else = []
    lib_in_out_names.result_names_counter_else = 0
   
    
    
    if_array = IfElse_Arrays.if_array[if_no]
    else_array = IfElse_Arrays.else_array[if_no]
    delay_if_cycle = IfElse_Arrays.if_delay[if_no]
    delay_else_cycle = IfElse_Arrays.else_delay[if_no]
    start_address = IfElse_Arrays.start_address_if[if_no]
    
    
    
    if_input_names = []
    global else_input_names 
    
    if_else_output_names = []
    
    # Generate if module
    for i in range (0, delay_else_cycle):
        operands = else_array[i]['operand_name_array']
        no_operands = else_array[i]['number_of_operands']        
        operator = else_array[i]['operator'] 
        results = else_array[i]['result_name_array']
        no_results = else_array[i]['number_of_results']
        previous_addresses = else_array[i]['previous_address']
        no_previous_adresses = else_array[i]['no_of_previous_address']
        delay_cycles = else_array[i]['delay cycles']
        
        
        
        
        
        # define result names
        # result_names_if = []
        # result_name_no_if = []
        # result_names_counter_if = 0
        
        # result_names_else = []
        # result_name_no_else = []
        # result_names_counter_else = 0
        
        # Judge if input's previous address is before the if
        #print(no_operands)
        for j in range (0, no_operands):
            # when the previous address is before if start address
            # flag = 1
            
            flag_iterative = 0
            flag_before = 0
            # Find if the oprands are numbers or not
            if(operands[j].isnumeric()):
                if(j == 0):
                    previous_array_start = 0
                    previous_array_end = no_previous_adresses[j]
                    #print(operands[j]) 
                
                # for the second or following operands
                else:
                    previous_array_start = previous_array_end
                    previous_array_end = no_previous_adresses[j] + previous_array_end
                    #print(operands[j])
            
            # If the oprands are not numbers
            else:
                #print(operands[j])    
                flag_iterative = 0
                flag_before = 0
                
                # For the first operand
                if(j == 0):
                    previous_array_start = 0
                    previous_array_end = no_previous_adresses[j]
                    #print(operands[j]) 
                
                # for the second or following operands
                else:
                    previous_array_start = previous_array_end
                    previous_array_end = no_previous_adresses[j] + previous_array_end
                    #print(operands[j]) 
               
                # print("no_previous_adresses["+str(j)+"]")
                # print(no_previous_adresses[j])
                # print(operands[j]) 
                # print("previous: ")
                # print(previous_array_start) 
                # print(previous_array_end) 
                for k in range (previous_array_start, previous_array_end):
                    
                    
                    if(previous_addresses[k]<start_address):
                        flag_before = 1
                              
                # If this oprand is from outside if, then it should be an input
                if(flag_before == 1):
                    flag_iterative = 0
                    for l in range (0, len(else_input_names)):
                        if(else_input_names[l] == operands[j]):
                            flag_iterative = 1
                            #print(operands[j])
                    if(flag_iterative == 0):
                        else_input_names.append(operands[j])
                        #print(operands[j])
        
        
        
        match operator:
                case 0:
                    
                    do = 0
                    
                case 1:
                    name_comp = "addition_HDL_" + str(add_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1], file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " + " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\taddition_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    
                    f.close()
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    add_count = add_count + 1
                
                
                
                
                
                
                
                # -
                case 2:
                    name_comp = "subtraction_HDL_" + str(substract_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1], file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " - " +  input_name_1 + "\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tSubtraction_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    substract_count = substract_count + 1           
                
                
                
                
                
                
                
                
                
                # *
                case 3:
                    name_comp = "mul_HDL_" + str(mul_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1], file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " * " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    
                    f.write("\tmul_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    mul_count = mul_count + 1
            
            
            
            
            
            
            
            
            
            
            
                # /
                case 4:
                    name_comp = "division_HDL_" + str(div_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1],file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + " / " +  input_name_1 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tDivision_always "+ name_comp +"(" + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", clk, " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    div_count = div_count + 1
                
                
                
                
                
                
                
                
                
                # Power
                case 5:
                    name_comp = "power_HDL_" + str(power_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1], file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                     
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = Pow("
                            + input_name_0 + ", " +  input_name_1 + ")\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tPower_PN "+ name_comp +"( clk, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            ", " + start_line_name + ", reset, " +
                            valid_line_name + "," + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    power_count = power_count + 1
                
                
                
                
                
                
                
                
                
                
                # Log
                case 6:
                    name_comp = "log_HDL_" + str(log_count)
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    input_name_1 = input_name_decider_else(operands[1], file_name)
                    result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = log"
                            + input_name_0 + " ( " +  input_name_1 + ")\n"
                                 )
                    
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tlog_inout "+ name_comp + "( " + start_line_name
                            + ", clk, reset, " + input_name_0 
                            + ", "  + input_name_1 + ", " + result_name_ + 
                            "," + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    
                    
                    
                    log_count = log_count + 1
                
                
                
                
                
                
                
                # SQRT
                case 7:
                    name_comp = "sqrt_HDL_" + str(sqrt_count)
                    
                    
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    #input_name_1 = input_name_decider(operands[1])
                    result_name_ = result_name_adder_else(results[0],file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = sqrt( "
                            + input_name_0 + " )\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tsqrt "+ name_comp + " ( clk, " + input_name_0 +
                            ", " + start_line_name
                            + ", reset, " + result_name_ + 
                            ", " + busy_line_name + ", " + valid_line_name 
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sqrt_count = sqrt_count + 1
                
                
                
                
                
                
                # SinCosTan
                case 8:
                    name_comp = "sincostan_HDL_" + str(sincostan_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    input_name_0 = input_name_decider_else(operands[0], file_name)
                    #input_name_1 = input_name_decider(operands[1])                   
                    result_name_0 = result_name_adder_else(results[0], file_name)
                    result_name_1 = result_name_adder_else(results[1], file_name)
                    result_name_2 = result_name_adder_else(results[2], file_name)
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_0 + " = sin("
                            + input_name_0 + ")\n \t//" + result_name_1 + " = cos("
                            + input_name_0 + ")\n \t//"+ result_name_2 + " = tan("
                            + input_name_0 + ")\n "
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\ttan_inout "+ name_comp + " ( clk, " + input_name_0 + 
                            ", " + result_name_0 + ", " + result_name_1 + ", " 
                            + result_name_2 + ", " + start_line_name
                            + ", reset, " + valid_line_name +
                            ", " + busy_line_name
                            + ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    sincostan_count = sincostan_count + 1
                
                
                
                
                
                
                
                
                
                
                # Value / Delay
                case 9:
                    name_comp = "Value_HDL_" + str(value_count)
                    if(i == 0):
                        previous_valid = "start"
                    
                    start_line_name = "start_" + name_comp
                    valid_line_name = "valid_" + name_comp 
                    busy_line_name = "busy_" + name_comp
                    
                    
                    
                    if(operands[0] ==results[0]):
                        #(operands[0])
                        input_name_0 = result_name_adder_else(operands[0], file_name)
                        #print(input_name_0)
                        result_name_ = result_name_adder_else(results[0], file_name)
                        
                    else:
                        input_name_0 = input_name_decider_else(operands[0], file_name)
                        result_name_ = result_name_adder_else(results[0], file_name)
                    
                    
                    
                    f = open(file_name, "a")
                    # Comments
                    f.write("\t//Proceed with " + result_name_ + " = "
                            + input_name_0 + "\n"
                                 )
                    f.write("\twire "+ start_line_name +";\n" + 
                            "\twire "+ valid_line_name +";\n" +
                            "\twire "+ busy_line_name +";\n"        
                                 )
                    f.write("\tdelay "+ name_comp + " (" + start_line_name
                            +", clk, reset, " + input_name_0 + 
                            ", " + result_name_ + ", " + busy_line_name 
                            +", " + valid_line_name +
                             ");\n"
                                 )
                    f.write("\tassign "+ start_line_name + " = start;\n\n\n"        
                                 )
                    f.close()
                    
                    
                    
                    previous_valid = valid_line_name
                    
                    if(i == delay_else_cycle-1):
                        f = open(file_name, "a")
                        f.write("\tassign "+ "valid" + " = " + valid_line_name
                                +";\n"        
                                     )
                        f.write("\tassign "+ "busy" + " = " + busy_line_name
                                +";\n"        
                                     )
                        f.close()
                    value_count = value_count + 1
                
                case _:
                    print("No such function")
    
    
    
    
    
    
    f = open(file_name, "a")
    f.write("endmodule")
    f.close()








