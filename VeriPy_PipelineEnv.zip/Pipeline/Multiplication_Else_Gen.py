# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 10:21:09 2024

@author: elx22yz
"""

''' 07/03/2024
    Version 0.0.1
    This is the function to generate Multiplication into the record structure array
    by calling Add_Into_Structure_Array.py, which is a fundamental function 
    that applies to all the functions.
    
'''

from Add_Into_Structure_Array_Else import Add_Into_Structure_Array_Else
import itertools
from Template import Max_number_operands     
from Template import Max_number_results

def Multiplication_Else_V(c, a, b):
      
    results = list(itertools.repeat('0', Max_number_results))
    results[0] = c
    inputs = list(itertools.repeat('0', Max_number_operands))
    inputs[0] = a
    inputs[1] = b  
    operator_num = 3
    number_of_operands = 2
    number_of_results = 1
    
    Add_Into_Structure_Array_Else(results, inputs, operator_num, number_of_operands, 
                                 number_of_results, 1)
