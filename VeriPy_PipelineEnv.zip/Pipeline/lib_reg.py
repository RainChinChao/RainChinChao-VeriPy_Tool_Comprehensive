# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 13:32:49 2024

@author: elx22yz
"""





import numpy as np

import itertools

Max_no_reg_arrays = 1000

reg_array_counter = 0

reg_array_sample = []



reg_array_names = []

reg_array_list = [reg_array_sample.copy() for _ in range(Max_no_reg_arrays)]









