# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 14:00:48 2024

@author: elx22yz
"""

''' 05/06/2024
    Version 0.0.1
    This is the function to do the recall that helps to generate all the 
    Verilog coding and store the backwards level of the pipeline binary tree
    
'''


import numpy as np
from Template import dt
import IfElse_Arrays
import lib_para
from Verilog_IF_Else_Gen import if_module_gen
from Verilog_IF_Else_Gen import else_module_gen
import Verilog_IF_Else_Gen
import Verilog_IF_Else_Inout_Gen
from array_print_top import array_print_top
from input_output_print_top import input_output_print_top
from array_content_print_top import array_content_print_top

import lib_in_out_names 
file_name = 0

import lib_para
import Verilog_Generation
import lib_in_out_names
import itertools
from equation_selection_generation import equation_selection_generation


# This lib contains the level info for the pipeline binary tree
import lib_pipe_BinaryTree




def recall_function(address, final, file_name):
    binary_tree_main = lib_para.Eq_record
    

    
    #top_generation_function_pipe(file_name)

    
    # When the final result name is under processing
    if(final == 1):

        equation_selection_generation(address, file_name, lib_pipe_BinaryTree.level_count)
        
        
        
        # Find out the previous address and do the recall
        previous_addresses = binary_tree_main[address]['previous_address']
        no_previous_adresses = binary_tree_main[address]['no_of_previous_address']
        no_operands = binary_tree_main[address]['number_of_operands']   
        
        
        current_strat_address = 0 
        for i in range (0, no_operands):
           
            for j in range (current_strat_address, current_strat_address + no_previous_adresses[i]):
                    
                recall_function(previous_addresses[j], 0, file_name)
        
            current_strat_address = no_previous_adresses[i] + current_strat_address
        
        
        
        
        
        
        
        
        
        
        
   